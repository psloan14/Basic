package com.example.administrator.ssb;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // find our buttons and set onClickListeners for all
        ImageButton one = (ImageButton)findViewById(R.id.recimage);
        ImageButton two = (ImageButton)findViewById(R.id.smimage);
        ImageButton three = (ImageButton)findViewById(R.id.jobimage);
        ImageButton four = (ImageButton)findViewById(R.id.qcimage);
        ImageButton five = (ImageButton)findViewById(R.id.nlimage);
        ImageButton six = (ImageButton)findViewById(R.id.tatimage);
        one.setOnClickListener(this);
        two.setOnClickListener(this);
        three.setOnClickListener(this);
        four.setOnClickListener(this);
        five.setOnClickListener(this);
        six.setOnClickListener(this);
        }

    public void onClick(View v) {

        // do something based on the button that was clicked
        switch(v.getId()) {
            case R.id.recimage:
                // create an intent indicating we want
                // to start the activity.

                Intent i = new Intent(this, RECjava.class);
                // start the activity based on the Intent
                startActivity(i);
                break;

            case R.id.smimage:
                Intent j = new Intent(this, SMjava.class);

                // start the activity based on the Intent
                startActivity(j);
                break;

            case R.id.jobimage:
                Intent k = new Intent(this, JOBSjava.class);

                // start the activity based on the Intent
                startActivity(k);
                break;

            case R.id.qcimage:
                Intent l = new Intent(this, TAXIjava.class);

                // start the activity based on the Intent
                startActivity(l);
                break;

            case R.id.nlimage:
                Intent m = new Intent(this, NLjava.class);

                // start the activity based on the Intent
                startActivityForResult(m, 0);
                break;

            case R.id.tatimage:
                Intent n = new Intent(this, TATjava.class);

                // start the activity based on the Intent
                startActivity(n);
                break;
            default:
                finish();
        }

    };
}


