package com.example.administrator.ssb;


import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.media.Image;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.Toast;

public class JOBSjava extends AppCompatActivity implements View.OnClickListener {


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.jobs_main);

        // find our buttons and set onClickListeners for all
        ImageButton one = (ImageButton)findViewById(R.id.gradimage);
        ImageButton two = (ImageButton)findViewById(R.id.pttimage);
        ImageButton three = (ImageButton)findViewById(R.id.placement);

        one.setOnClickListener(this);
        two.setOnClickListener(this);
        three.setOnClickListener(this);

    }

    public void onClick(View v) {

        // do something based on the button that was clicked
        switch(v.getId()) {
            case R.id.gradimage:
                // create an intent indicating we want
                // to start the activity.

                Intent intentgrad = new Intent();
                intentgrad.setAction(Intent.ACTION_VIEW);
                intentgrad.addCategory(Intent.CATEGORY_BROWSABLE);
                intentgrad.setData(Uri.parse("http://www.nijobs.com/Graduate"));

                startActivity(intentgrad);
                // start the activity based on the Intent
                break;

            case R.id.pttimage:
                // create an intent indicating we want
                // to start the activity.

                Intent intentpt = new Intent();
                intentpt.setAction(Intent.ACTION_VIEW);
                intentpt.addCategory(Intent.CATEGORY_BROWSABLE);
                intentpt.setData(Uri.parse("https://www.jobcentreonline.com/JCOLFront/FreeSearchJobList.aspx?FreeSearch=belfast"));

                startActivity(intentpt);
                // start the activity based on the Intent
                break;

            case R.id.placement:
                // create an intent indicating we want
                // to start the activity.

                Intent intentplacement = new Intent();
                intentplacement.setAction(Intent.ACTION_VIEW);
                intentplacement.addCategory(Intent.CATEGORY_BROWSABLE);
                intentplacement.setData(Uri.parse("http://www.indeed.co.uk/Student-Placement-jobs-in-Northern-Ireland"));

                startActivity(intentplacement);
                // start the activity based on the Intent
                break;

            default:
                finish();
        }

    };

}


