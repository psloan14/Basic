package com.example.administrator.ssb;

import android.app.Activity;
import android.content.res.Configuration;
import android.widget.Toast;

/**
 * Created by 40084949 on 14/03/2016.
 */
public class NLjava extends Activity {

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        // Checks the orientation of the screen
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            Toast.makeText(this, "landscape", Toast.LENGTH_SHORT).show();
        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT){
            Toast.makeText(this, "portrait", Toast.LENGTH_SHORT).show();
        }
    };
}

