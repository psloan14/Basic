﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NUnit.Framework;

/// <summary>
/// Summary description for Class1
/// </summary>
/// 
[TestFixture]
public class Class1
{
    [Test]
	public void Test_Login()
	{
		//
		// TODO: Add constructor logic here
		//

        // We tried to find an appropriate area to test as we didnt complete stories 16 and 17. We did use our acceptance tests to test methods. - Team Winter Is Scrumming
    
    }
}