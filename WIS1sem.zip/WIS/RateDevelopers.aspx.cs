﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class RateDevelopers : System.Web.UI.Page
{
    // Declares Private Static int for masterId
    private static int masterId;
    private static int master_Id;

    private static int updateProductivity;
    private static int updateCodeQuality;
    private static int updateAdherence;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["useridsession"] == null)
        {
            // If user is not logged in then the web app will redirect back to homepage
            Response.Redirect("Default.aspx");

        }

        else
        {
            // If user is logged in then user Id will be assigned to the variable masterId
            masterId = int.Parse(Session["useridsession"].ToString());


        }

        // parses the Session "current_project" to the variable project_id
        int project_id = int.Parse(Session["current_project"].ToString());

        // parses the Session "current_sprint" to the variable sprint_Id
        int sprint_Id = (int)Session["current_Sprint"];

        // sets up connection string to connect to database
        string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        // declares sql connection type
        SqlConnection myConnection = new SqlConnection(connectionString);

        // opens connection
        myConnection.Open();

        // query is sent to database
        string query = "SELECT [scrum_master.table].*, [user.table].* FROM [scrum_master.table] INNER JOIN [user.table] ON [scrum_master.table].user_id = [user.table].Id WHERE [scrum_master.table].user_id = @userId AND [scrum_master.table].project_id = @projectId";


        SqlCommand myCommand = new SqlCommand(query, myConnection);

        // passes variables through paramaters using Session values
        myCommand.Parameters.AddWithValue("@userId", masterId);
        myCommand.Parameters.AddWithValue("@projectId", project_id);

        // Decalres SqlReader to read from the database 
        SqlDataReader rdr = myCommand.ExecuteReader();
        while (rdr.Read())
        {
            // reads the value of column "Master" and assigns it to string
            string id_Master = rdr["user_id"].ToString();
            int new_Master = Convert.ToInt32(id_Master);
            master_Id = new_Master;
        }

        int master = Convert.ToInt32(master_Id);

        // Checks if "Master" column value = 0 and is not assigned a scrum master
        if (master != masterId)
        {
            Response.Redirect("Home.aspx");
        }

        // Closes reader
        rdr.Close();

        // Closes connection
        myConnection.Close();

        // sets up connection string to connect to the database
        string connectionString2 = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        //Declaring a new SQL Connection type and opens a new connection
        SqlConnection myConnection2 = new SqlConnection(connectionString2);

        myConnection2.Open();


        //Searches the Sprint table in the database that will use the end date to display the button.
        string query2 = "SELECT [sprint.table].Id, [sprint.table].end_date FROM [sprint.table] WHERE [sprint.table].Id = @sprint_Id";

        SqlCommand myCommand2 = new SqlCommand(query2, myConnection2);
        myCommand2.Parameters.AddWithValue("@sprint_Id", sprint_Id);

        SqlDataReader rdr2 = myCommand2.ExecuteReader();

        //Checks to see if the Current Sprint has ended, if it has ended then the button labled RateDevelopers will display only allowing the Scrum Master to click on it and be directed to the Rate Developers page.
        DateTime dateNow = DateTime.Now;
        // DateTime end1 = new DateTime(2015, 12, 03);


        while (rdr2.Read())
        {
            DateTime end = rdr2.GetDateTime(1);
            if ((DateTime.Compare(end, dateNow) < 0))
            {

            }
            else
            {
                Response.Redirect("Home.aspx");
            }
        }
        //Closes the reader
        rdr2.Close();

        // Close the connection
        myConnection2.Close();



        // sets up connection string to connect to database
        string connectionString3 = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        //Declares the SQL Connection and opens connection
        SqlConnection myConnection3 = new SqlConnection(connectionString3);

        myConnection3.Open();

        // parses the Session "developerid" to the variable current_developer
        int current_developer = int.Parse(Request.QueryString["developerId"]);

        //Query is sent to get the Developer's information
        string query3 = "SELECT [user.table].Name FROM [user.table] INNER JOIN [developer.table] ON [user.table].Id = [developer.table].user_id INNER JOIN [sprint.table] ON [sprint.table].Id = [developer.table].sprint_id WHERE [developer.table].sprint_id = @sprint_id AND [developer.table].user_id = @developerId";

        SqlCommand myCommand3 = new SqlCommand(query3, myConnection3);

        myCommand3.Parameters.AddWithValue("@developerId", current_developer);
        myCommand3.Parameters.AddWithValue("@sprint_id", sprint_Id);

        SqlDataReader rdr3 = myCommand3.ExecuteReader();

        //Create table for the information to be displayed
        while (rdr3.Read())
        {
            //Information gets added to the cells
            TableCell cell1 = new TableCell();

            string dev_Name = (rdr3.GetString(0));

            devName.Text = dev_Name.ToString();

            //Cells are created in the table
            TableRow row = new TableRow();

            row.Cells.Add(cell1);
            rateDevelopers.Rows.Add(row);


        }

        // closes reader
        rdr3.Close();

        // closes connection
        myConnection3.Close();

    }
    protected void updateDevRating_Click(object sender, EventArgs e)
    {
        // sets up connection string to connect to database
        string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        //Declares the SQL Connection and opens connection
        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();

        int current_developer = int.Parse(Request.QueryString["developerId"]);
        
        
        int sprint_Id = (int)Session["current_Sprint"];


        updateProductivity = devProductivity.SelectedIndex;
        updateCodeQuality = devCodeQuality.SelectedIndex;
        updateAdherence = devAgileAdherence.SelectedIndex;

        //Query to update the three areas of developer ratings
        string query = "UPDATE [developer.table] SET productivity=@Productivity, code_quality=@codeQuality, adherence=@adherence WHERE[developer.table].user_id = @developerId AND [developer.table].sprint_id = @sprint_id";
        
        SqlCommand myCommand = new SqlCommand(query, myConnection);

        //Updates the Developer table with the ratings
        myCommand.Parameters.AddWithValue("@developerId", current_developer);
        myCommand.Parameters.AddWithValue("@Productivity", updateProductivity);
        myCommand.Parameters.AddWithValue("@codeQuality", updateCodeQuality);
        myCommand.Parameters.AddWithValue("@adherence", updateAdherence);
        myCommand.Parameters.AddWithValue("@sprint_id", sprint_Id);
        
        myCommand.ExecuteNonQuery();

        myConnection.Close();

        //Message displayed when the ratings have been updated in the table in the Database
        ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "alert('Your review scores have been updated for this developer in this sprint.');", true);
        return;

        

        

    }

    protected void Back_Click(object sender, EventArgs e)
    {

        Response.Redirect("DeveloperRatings.aspx");
    }
}
    