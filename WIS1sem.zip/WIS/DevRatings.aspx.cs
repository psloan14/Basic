﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

using System.Text;
using System.Configuration;



public partial class DevRatings : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        //int sprint_id = int.Parse(Session["current_sprint"].ToString());


        string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();

        string query = "SELECT [user.table].Name, [developer.table].productivity, [developer.table].code_quality, [developer.table].adherence FROM [user.table] INNER JOIN [developer.table] ON [user.table].Id = [developer.table].user_id INNER JOIN [sprint.table] ON [sprint.table].Id = [developer.table].sprint_id WHERE [developer.table].sprint_id = @sprint_id";

        int sprint = 14;
        SqlCommand myCommand = new SqlCommand(query, myConnection);
        myCommand.Parameters.AddWithValue("@sprint_id", sprint);


        SqlDataReader rdr = myCommand.ExecuteReader();

        while (rdr.Read())
        {
            TableCell cell1 = new TableCell();
            TableCell cell2 = new TableCell();
            TableCell cell3 = new TableCell();
            TableCell cell4 = new TableCell();


            string Name = (rdr.GetString(0));
            int productivity = (rdr.GetInt32(1));
            int code_quality = (rdr.GetInt32(2));
            int adherence = (rdr.GetInt32(3));

            
            cell1.Text = rdr.GetString(0);
            cell2.Text = rdr.GetString(1);
            cell3.Text = rdr.GetString(2);
            cell4.Text = rdr.GetString(3);


            TableRow row = new TableRow();

            row.Cells.Add(cell1);
            row.Cells.Add(cell2);
            row.Cells.Add(cell3);
            row.Cells.Add(cell4);

            myTable.Rows.Add(row);


        }

        // Closes reader
        rdr.Close();
    }
}