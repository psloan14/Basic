﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Web.UI.DataVisualization.Charting;
using iTextSharp.text;
using iTextSharp.text.pdf;

public partial class BurndownChart : System.Web.UI.Page
{


    protected void Page_Load(object sender, EventArgs e)
    {

        // makes sure the user is logged
        int sessionId = 0;
        if (Session["useridsession"] == null)
        {

            Response.Redirect("Default.aspx");

        }

        else
        {
            sessionId = int.Parse(Session["useridsession"].ToString());

        }
        int sprint_id = (int)Session["current_Sprint"];

        string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();

        //Query gets all the progress made in the sprint
        string query = "SELECT [progress.table].time_stamp, [progress.table].hours_progressed FROM [progress.table]" +
            " INNER JOIN [task.table] ON [task.table].Id = [progress.table].task_id" +
            " INNER JOIN [story.table] ON [story.table].Id = [task.table].story_id WHERE [story.table].assigned_id = @sprint_id ORDER BY [progress.table].time_stamp ASC";

        SqlCommand myCommand = new SqlCommand(query, myConnection);
        myCommand.Parameters.AddWithValue("@sprint_id", sprint_id);

        SqlDataReader rdr = myCommand.ExecuteReader();
        Dictionary <DateTime, int> data = new Dictionary<DateTime, int>();

        while (rdr.Read()) //Loop saves all data obtained in a dictionary (KEY = date, VALUE = hours)
        {
            if (!data.ContainsKey(((DateTime)rdr[0]).Date)){
                data.Add(((DateTime)rdr["time_stamp"]).Date, (int)rdr["hours_progressed"]);
            }
            else{
                data[((DateTime)rdr["time_stamp"]).Date] += (int)rdr["hours_progressed"];
            }
            
        }
        rdr.Close();

        //Takes reamining hours in the sprint
        query = "SELECT [task.table].hours_left FROM [task.table] INNER JOIN [story.table] ON [story.table].Id = [task.table].story_id WHERE [story.table].assigned_id = @sprint_id";
        myCommand = new SqlCommand(query, myConnection);
        myCommand.Parameters.AddWithValue("@sprint_id", sprint_id);

        rdr = myCommand.ExecuteReader();

        int hours_remaining = 0;

        while (rdr.Read()) {
            hours_remaining += (int)rdr[0];
        }

        rdr.Close();

        //gets the end date and start date of the sprint
        query = "SELECT [sprint.table].start_date, [sprint.table].end_date FROM [sprint.table] WHERE [sprint.table].Id = @sprint_id";

        myCommand = new SqlCommand(query, myConnection);
        myCommand.Parameters.AddWithValue("@sprint_id", sprint_id);

        rdr = myCommand.ExecuteReader();

        DateTime start_date = new DateTime(1900, 1, 1);
        DateTime end_date = new DateTime(1900, 1, 1);

        while (rdr.Read())
        {
            start_date = (DateTime)rdr[0];
            end_date = (DateTime)rdr[1];
        }
        rdr.Close();

        TimeSpan time = end_date.Date - start_date.Date;//gets the length of the sprint (in days)
        DateTime date = new DateTime(end_date.Year, end_date.Month, end_date.Day); //new date object with the end date
        int nextvalue = 0;// variables that save the hours progressed every day so they can be added to the previous date
        int temp = 0;

        //This loop goes through all the days in the sprint from last to first, updating how many hours left are in each day. For doing this it adds the progress
        //done the day after to the remaining hours.
        for(int days = time.Days+1; days>0; days--){
            if (!data.ContainsKey(date))
            {
                
                data[date] = hours_remaining + nextvalue;
                hours_remaining = data[date];
                nextvalue = 0;
            }
            else
            {
                temp = data[date];
                data[date] = hours_remaining + nextvalue;
                nextvalue = temp;
                hours_remaining = data[date];
            }
            date = date - new TimeSpan(24, 0, 0);
        }
        //Put the dates as strings in an array so it can be pased as a data source to the chart
        string[] xValues = new string[time.Days+1];
        List<DateTime> xValuesList = new List<DateTime>();
        int index = 0;
        foreach (DateTime key in data.Keys)
        {
            xValuesList.Add(key);
            
        }
        xValuesList.Sort();//Orders the dates before adding them to the final array
        foreach (DateTime key in xValuesList)
        {
            xValues[index] = key.Date.ToString(); //This will fail if you make progress in a day that is out of the sprint. Don't do it.
            index++;
        }
        //Put the hours remaining in an array so it can be pased as a data source to the chart
        int[] yValues = new int[xValues.Length];
        index = 0;

        foreach (DateTime key in xValuesList)
        {
            yValues[index] = data[key];
            index++;
        }
        double[] yLineValues = new double[yValues.Length];
        double y0 = yLineValues[0] = yValues[0];
        double y1 = yLineValues[yValues.Length - 1] = yValues[yValues.Length - 1];
        
        int[] xLineValues = new int[xValues.Length];
        index = 0;
        foreach (string caca in xValues)
        {
            xLineValues[index] = index;
            index++;
        }
        index = 0;
        foreach (int xvalue in xLineValues)
        {
            if (index != 0 && index != xLineValues.Length - 1)
            {
                yLineValues[index] = ((y1 - y0) / xLineValues[xValues.Length - 1]) * xvalue + y0;
            }
            
            index++;
            
        }

        //Settings for the chart (axis intervals)
        Chart1.ChartAreas["ChartArea1"].AxisX.IntervalType = DateTimeIntervalType.Days;
        Chart1.ChartAreas["ChartArea1"].AxisX.Interval = 1;
        Chart1.ChartAreas["ChartArea1"].AxisY.Interval = 1;
        Chart1.Series["Series1"].Points.DataBindXY(xValues, yValues);
        Chart1.Series["Series2"].Points.DataBindXY(xValues, yLineValues);

    }

    protected void btnExportPDF_Click(object sender, EventArgs e)
    {
        Document pdfDoc = new Document(PageSize.A4, 0, 0, 150, 20);
        PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
        pdfDoc.Open();
        using (MemoryStream stream = new MemoryStream())
        {
            Chart1.SaveImage(stream, ChartImageFormat.Png);
            iTextSharp.text.Image chartImage = iTextSharp.text.Image.GetInstance(stream.GetBuffer());
            chartImage.ScalePercent(50f);
            pdfDoc.Add(chartImage);
            pdfDoc.Close();


            Response.ContentType = "application/pdf";
            Response.AddHeader("content-disposition", "attachment;filename=Chart.pdf");
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Write(pdfDoc);
            Response.End();
        }
    }
        protected void SendPDFEmail_Click(object sender, EventArgs e)


    {

        Response.Redirect("EmailBurnDown.aspx");


    }
}