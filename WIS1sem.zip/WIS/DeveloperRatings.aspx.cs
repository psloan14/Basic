﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

using System.Text;
using System.Configuration;
public partial class DeveloperRatings : System.Web.UI.Page
{
    // Declares Private Static int for masterId
    private static int masterId;
    private static int master_Id;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["useridsession"] == null)
        {
            // If user is not logged in then the web app will redirect back to homepage
            Response.Redirect("Default.aspx");

        }

        else
        {
            // If user is logged in then user Id will be assigned to the variable masterId
            masterId = int.Parse(Session["useridsession"].ToString());


        }

        // parses the Session "current_project" to the variable project_id
        int project_id = int.Parse(Session["current_project"].ToString());

        // parses the Session "current_sprint" to the variable sprint_Id
        int sprint_Id = (int)Session["current_Sprint"];

        // sets up connection string to connect to database
        string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        // declares sql connection type
        SqlConnection myConnection = new SqlConnection(connectionString);

        // opens connection
        myConnection.Open();

        // query is sent to database
        string query = "SELECT [scrum_master.table].*, [user.table].* FROM [scrum_master.table] INNER JOIN [user.table] ON [scrum_master.table].user_id = [user.table].Id WHERE [scrum_master.table].user_id = @userId AND [scrum_master.table].project_id = @projectId";


        SqlCommand myCommand = new SqlCommand(query, myConnection);

        // passes variables through paramaters using Session values
        myCommand.Parameters.AddWithValue("@userId", masterId);
        myCommand.Parameters.AddWithValue("@projectId", project_id);

        // Decalres SqlReader to read from the database 
        SqlDataReader rdr = myCommand.ExecuteReader();
        while (rdr.Read())
        {
            // reads the value of column "Master" and assigns it to string
            string id_Master = rdr["user_id"].ToString();
            int new_Master = Convert.ToInt32(id_Master);
            master_Id = new_Master;
        }

        int master = Convert.ToInt32(master_Id);

        // Checks if "Master" column value = 0 and is not assigned a scrum master
        if (master != masterId)
        {
            Response.Redirect("Home.aspx");
        }

        // Closes reader
        rdr.Close();

        // Closes connection
        myConnection.Close();

        // sets up connection string to connect to the database
        string connectionString2 = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        //Declaring a new SQL Connection type and opens a new connection
        SqlConnection myConnection2 = new SqlConnection(connectionString2);

        myConnection2.Open();


        //Searches the Sprint table in the database that will use the end date to display the button.
        string query2 = "SELECT [sprint.table].Id, [sprint.table].end_date FROM [sprint.table] WHERE [sprint.table].Id = @sprint_Id";

        SqlCommand myCommand2 = new SqlCommand(query2, myConnection2);
        myCommand2.Parameters.AddWithValue("@sprint_Id", sprint_Id);

        SqlDataReader rdr2 = myCommand2.ExecuteReader();

        //Checks to see if the Current Sprint has ended, if it has ended then the button labled RateDevelopers will display only allowing the Scrum Master to click on it and be directed to the Rate Developers page.
        DateTime dateNow = DateTime.Now;
        // DateTime end1 = new DateTime(2015, 12, 02);


        while (rdr2.Read())
        {
            DateTime end = rdr2.GetDateTime(1);
            if ((DateTime.Compare(end, dateNow) < 0))
            {

            }
            else
            {
                Response.Redirect("Home.aspx");
            }
        }
        //Closes the reader
        rdr2.Close();

        // Close the connection
        myConnection2.Close();

        // setting up the connection string to connect to database and then declaring the SQL connection type
        string connectionString1 = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        SqlConnection myConnection1 = new SqlConnection(connectionString);

        //Opens the connection 
        myConnection1.Open();

        //Sending the query to the database to display the developers details
        string query1 = "SELECT [user.table].Id, [user.table].Name, [user.table].Email, [user.table].Tags FROM [user.table] INNER JOIN [developer.table] ON [user.table].Id = [developer.table].user_id INNER JOIN [sprint.table] ON [sprint.table].Id = [developer.table].sprint_id WHERE [developer.table].sprint_id = @sprint_id";

        SqlCommand myCommand1 = new SqlCommand(query1, myConnection1);
        myCommand1.Parameters.AddWithValue("@sprint_id", sprint_Id);


        SqlDataReader rdr1 = myCommand1.ExecuteReader();

        //Creating the table for the information to be displayed
        while (rdr1.Read())
        {
            TableCell cell1 = new TableCell();
            TableCell cell2 = new TableCell();
            TableCell cell3 = new TableCell();


            int devId = (rdr1.GetInt32(0));
            String devName = (rdr1.GetString(1));
            String devEmail = (rdr1.GetString(2));
            String devTag = (rdr1.GetString(3));

            //What information the cells will hold, cell1 will hold a hyperlink that will take you to the RateDevelopers Page to give that specific developer a rating.
            HyperLink link = new HyperLink();
            link.NavigateUrl = "RateDevelopers.aspx?developerId="+devId.ToString();
            link.Text = devName.ToString();
            cell1.Controls.Add(link);
            cell2.Text = devEmail.ToString();
            cell3.Text = devTag.ToString();
            
            //Adding the cells 
            TableRow row = new TableRow();

            row.Cells.Add(cell1);
            row.Cells.Add(cell2);
            row.Cells.Add(cell3);


            myDevelopers.Rows.Add(row);


        }

        // Closes reader
        rdr1.Close();
        

        // Closes the connection
        myConnection1.Close();
        
    }


    }



  