﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;


public partial class AssignSprintBacklog : System.Web.UI.Page
{
    // Declares a private int
    private int story_id;

    // Declares an array of tuples to store a list of results fro database
    private static List<Tuple<int, string>> results = new List<Tuple<int, string>>();

    // Declares Private Static int for masterId
    private static int masterId;
    private static int master_Id;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["useridsession"] == null)
            {
                // If user is not logged in then the web app will redirect back to homepage
                Response.Redirect("Default.aspx");

            }

            else
            {
                // If user is logged in then user Id will be assigned to the variable masterId
                masterId = int.Parse(Session["useridsession"].ToString());


            }

            // parses the Session "current_project" to the variable project_id
            int project_id = int.Parse(Session["current_project"].ToString());

            // parses the Session "current_sprint" to the variable sprint_Id
            int sprint_Id = (int)Session["current_Sprint"];

            // sets up connection string to connect to database
            string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

            // declares sql connection type
            SqlConnection myConnection = new SqlConnection(connectionString);

            // opens connection
            myConnection.Open();

            // query is sent to database
            string query = "SELECT [scrum_master.table].*, [user.table].* FROM [scrum_master.table] INNER JOIN [user.table] ON [scrum_master.table].user_id = [user.table].Id WHERE [scrum_master.table].user_id = @userId AND [scrum_master.table].project_id = @projectId";


            SqlCommand myCommand = new SqlCommand(query, myConnection);

            // passes variables through paramaters using Session values
            myCommand.Parameters.AddWithValue("@userId", masterId);
            myCommand.Parameters.AddWithValue("@projectId", project_id);

            // Decalres SqlReader to read from the database 
            SqlDataReader rdr = myCommand.ExecuteReader();
            while (rdr.Read())
            {
                // reads the value of column "Master" and assigns it to string
                string id_Master = rdr["user_id"].ToString();
                int new_Master = Convert.ToInt32(id_Master);
                master_Id = new_Master;
            }

            int master = Convert.ToInt32(master_Id);

            // Checks if "Master" column value = 0 and is not assigned a scrum master
            if (master != masterId)
            {
                Response.Redirect("Home.aspx");
            }

            // Closes reader
            rdr.Close();

            // Closes connection
            myConnection.Close();

            // sets up connection string to connect to database
            string connectionString1 = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

            // declares sql connection type
            SqlConnection myConnection1 = new SqlConnection(connectionString1);

            // opens connection
            myConnection1.Open();


            // Sends query to database to get user stories that are assigned to current select project
            // CHANGED QUERY TO SHOW UP STORIES THAT HAVEN'T BEEN ASSIGNED - THIS IS SO USER IS NOT ABLE TO TRY AND ASSIGN STORIES THAT GHAVE ALREADY BEEN ASSIGNED TO SPRINT. 
            string query1 = "SELECT [story.table].Id, description FROM [story.table] WHERE [story.table].project_id = @Id AND [story.table].assigned = '0'";

            SqlCommand myCommand1 = new SqlCommand(query1, myConnection1);

            // passes variables through parameters
            myCommand1.Parameters.AddWithValue("@Id", project_id);

            // executes a sql reader
            SqlDataReader rdr1 = myCommand1.ExecuteReader();


            while (rdr1.Read())
            {
                // retrieves story id 
                story_id = (rdr1.GetInt32(0));
                bool alreadyThere = false;
                foreach (ListItem item in productBacklog.Items)
                {
                    if (item.Value == productBacklog.ToString())
                    {
                        alreadyThere = true;
                        break;
                    }
                }
                if (!alreadyThere)
                {
                    // Adds items to listbox productBacklog
                    productBacklog.Items.Add(new ListItem(rdr1.GetString(1), story_id.ToString()));

                }


            }

            // closes reader
            rdr1.Close();
        }

    }


    protected void productBacklog_SelectedIndexChanged(object sender, EventArgs e)
    {
        // sets Sessions current_story to the selected user story selected
        Session["current_story"] = int.Parse(productBacklog.SelectedValue);

        // Sets Session value to int variable "currentStory"
        int currentStory = (int)Session["current_story"];
         


    }
    protected void addToSprint_Click(object sender, EventArgs e)
    {
            // Declares variable sprint
            int sprintId = 0;
            // Checks If Session "current_Sprint" is not null
            if (Session["current_Sprint"] != null)
            {
                // Assigns variable sprintId to Session Value
                sprintId = (int)Session["current_Sprint"];
            }
            else
            {
                // Redirects back to homepage
                Response.Redirect("Home.aspx");
            }

            // Assigns value of Session "current_story" to variable currentStory
            int currentStory = int.Parse(Session["current_story"].ToString()); 

            
            // Sets up connectionString
            string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;
            
            
            SqlConnection myConnection = new SqlConnection(connectionString);

            // Open connectionString
            myConnection.Open();
            
            // Sends Update query to database
            string query = "UPDATE [story.table] SET [story.table].assigned_id = @assigned_id, [story.table].assigned = @assigned WHERE [story.table].Id = @Id";

            SqlCommand myCommand = new SqlCommand(query, myConnection);
            
            // passes data through parameters
            myCommand.Parameters.AddWithValue("@Id", currentStory);
            myCommand.Parameters.AddWithValue("@assigned_id", sprintId);
            myCommand.Parameters.AddWithValue("@assigned", 1);
            
            // Execute query
            myCommand.ExecuteNonQuery();
            
            // Redirects to SprintBacklog page
            Response.Redirect("SprintBacklog.aspx");

        }
    }

