﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

using System.Text;
using System.Configuration;

public partial class ViewTasks : System.Web.UI.Page
{

    private static int devId = 0;
    private static int dev_Id = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        int userid = 0;
        if (Session["useridsession"] == null)
        {

            Response.Redirect("Default.aspx");

        }

        else
        {
            userid = int.Parse(Session["useridsession"].ToString());
        }

        devId = int.Parse(Session["useridsession"].ToString());

        // sets up connection string to connect to database
        string connectionString4 = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        // declares sql connection type
        SqlConnection myConnection4 = new SqlConnection(connectionString4);

        // opens connection
        myConnection4.Open();

        // query is sent to database
        string query4 = "SELECT [developer.table].* FROM [developer.table] WHERE [developer.table].user_id = @developerId";


        SqlCommand myCommand4 = new SqlCommand(query4, myConnection4);

        // passes variables through paramaters using Session values
        myCommand4.Parameters.AddWithValue("@developerId", devId);


        // Decalres SqlReader to read from the database 
        SqlDataReader rdr4 = myCommand4.ExecuteReader();
        while (rdr4.Read())
        {
            // reads the value of column "Developer" and assigns it to string
            string id_developer = rdr4["user_id"].ToString();
            int new_developer = Convert.ToInt32(id_developer);
            dev_Id = new_developer;
        }

        int developer = Convert.ToInt32(dev_Id);

        // Checks if "Developer" then panel is true
       if (developer == devId)
        {
            devOnly.Visible = true;
        }

        // Closes reader
        rdr4.Close();

        // Closes connection
        myConnection4.Close();


        int story_id = int.Parse(Session["current_story"].ToString()); //Takes the id of the current story



        string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();
        //query to find developers matching the criterion.
        string query = "SELECT [task.table].[Id], [task.table].[hours_left], [task.table].[blocked], [task.table].[description], [user.table].name FROM [task.table] LEFT OUTER JOIN [developer.table] ON [developer.table].Id = [task.table].dev_id LEFT OUTER JOIN [user.table] ON [user.table].Id = [developer.table].user_id WHERE [task.table].story_id = @story_id";


        SqlCommand myCommand = new SqlCommand(query, myConnection);
        myCommand.Parameters.AddWithValue("@story_id", story_id);


        SqlDataReader rdr = myCommand.ExecuteReader();
        


        while (rdr.Read())
        {  
            TableCell cell1 = new TableCell();
            TableCell cell2 = new TableCell();
            TableCell cell3 = new TableCell();
            TableCell cell4 = new TableCell();


            int task_id = (rdr.GetInt32(0));
            int hours_left = (rdr.GetInt32(1));
            int blocked = (rdr.GetInt32(2));

            
            HyperLink link = new HyperLink();
            link.NavigateUrl = "updatehours.aspx?id="+task_id.ToString();
            link.Text = rdr.GetString(3);
            cell1.Controls.Add(link); 
            cell2.Text = hours_left.ToString();

            if (blocked == 1)
            {
                cell3.Text = "Yes";
            }
            if (blocked == 0)
            {
                cell3.Text = "No";
            }
            
            try { cell4.Text = rdr.GetString(4); }
            catch (System.Data.SqlTypes.SqlNullValueException excp) { }
            

            TableRow row = new TableRow();

            row.Cells.Add(cell1);
            row.Cells.Add(cell2);
            row.Cells.Add(cell3);
            row.Cells.Add(cell4);
            
            myTable.Rows.Add(row);

            
        }

       


        

    }




    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("CreateTasks.aspx");
    }
}

