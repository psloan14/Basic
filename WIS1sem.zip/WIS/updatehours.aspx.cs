﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class updatehours : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["useridsession"] == null)
        {

            Response.Redirect("Default.aspx");

        }

        string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();

        int current_task = int.Parse(Request.QueryString["id"]);

        string query = "SELECT Id, blocked, description FROM [task.table] WHERE Id = @taskid";

        SqlCommand myCommand = new SqlCommand(query, myConnection);
        myCommand.Parameters.AddWithValue("@taskid", current_task);
        SqlDataReader rdr = myCommand.ExecuteReader();
        
        while (rdr.Read())
                {
                    string disname = rdr["Id"].ToString();
                    displaytaskid.Text = disname;

                    string distowncity = rdr["blocked"].ToString();
                    displayblocked.Text = distowncity;

                    string discountry = rdr["description"].ToString();
                    displaydesc.Text = discountry;

                 
                }

  
           
    rdr.Close();
    

    }


    
    protected void update_Click(object sender, EventArgs e)
    {
        string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();

        int current_task = int.Parse(Request.QueryString["id"]);


        int updatedhoursleft = int.Parse(displayhoursleft.Text);



        string query = "SELECT hours_left FROM [task.table] WHERE Id = @taskid";

        SqlCommand myCommand = new SqlCommand(query, myConnection);

        myCommand.Parameters.AddWithValue("@taskid", current_task);

        SqlDataReader rdr = myCommand.ExecuteReader();
        int previous_hours = 0;
        while (rdr.Read())
        {
            previous_hours = rdr.GetInt32(0);
        }
        rdr.Close();

        query = "UPDATE [task.table] SET hours_left=@newhoursleft WHERE Id=@taskid";

        myCommand = new SqlCommand(query, myConnection);

        myCommand.Parameters.AddWithValue("@taskid", current_task);
        myCommand.Parameters.AddWithValue("@newhoursleft", updatedhoursleft);


        myCommand.ExecuteNonQuery();


        query = "INSERT INTO [progress.table](task_id, time_stamp, hours_progressed) VALUES (@taskid, @timestamp, @hours)";

        myCommand = new SqlCommand(query, myConnection);

        myCommand.Parameters.AddWithValue("@taskid", current_task);
        myCommand.Parameters.AddWithValue("@timestamp", DateTime.Now);
        myCommand.Parameters.AddWithValue("@hours", previous_hours - updatedhoursleft);


        myCommand.ExecuteNonQuery();


        myConnection.Close();


        Response.Redirect("ViewTasks.aspx");
    }
}