﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
public partial class EditProductBacklog : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["useridsession"] == null)
            {

                Response.Redirect("Default.aspx");

            }

            string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

            SqlConnection myConnection = new SqlConnection(connectionString);

            myConnection.Open();

            int current_story = int.Parse(Request.QueryString["id"]);

            string query = "SELECT description FROM [story.table] WHERE Id=@storyid";

            SqlCommand myCommand = new SqlCommand(query, myConnection);

            myCommand.Parameters.AddWithValue("@storyid", current_story);
            

            SqlDataReader rdr = myCommand.ExecuteReader();
            while (rdr.Read())
            {
                description.Text = rdr.GetString(0);
            }
        }

    }



    protected void Save_Click(object sender, EventArgs e)
    {
        string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();

        int current_story = int.Parse(Request.QueryString["id"]);

        string query = "UPDATE [story.table] SET description=@des WHERE Id = @storyid1";
        SqlCommand myCommand = new SqlCommand(query, myConnection);
        myCommand.Parameters.AddWithValue("@storyid1", current_story);
        myCommand.Parameters.AddWithValue("@des", description.Text);

        myCommand.ExecuteNonQuery();
        Response.Redirect("AddViewPBacklog.aspx");


    }
}

  