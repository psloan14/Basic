﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

using System.Text;
using System.Configuration;

public partial class owntask : System.Web.UI.Page
{
    // Declares a private static int
    private static int devId = 0;

    private static int selectedtask = 0;

    private static int currentsprint = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            int userid = 0;
            if (Session["useridsession"] == null)
            {
                Response.Redirect("Default.aspx");
            }

            else
            {
                userid = int.Parse(Session["useridsession"].ToString());
            }


            int story_id = int.Parse(Session["current_story"].ToString()); //Takes the id of the current story

            string myStory = story_id.ToString();

            string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

            SqlConnection myConnection = new SqlConnection(connectionString);

            myConnection.Open();

            // query is sent to database
            string query = "SELECT [task.table].Id, description FROM [task.table] WHERE [task.table].story_id = @storyId AND dev_id IS NULL";

            SqlCommand myCommand = new SqlCommand(query, myConnection);

            // passes variables through paramaters using Session values
            myCommand.Parameters.AddWithValue("@storyid", story_id);

            // Decalres SqlReader to read from the database 
            SqlDataReader rdr = myCommand.ExecuteReader();

            // Clears items in listbox viewalltasks
            listoftasks.Items.Clear();
            while (rdr.Read())
            {
                bool alreadyThere = false;
                int task_id = (rdr.GetInt32(0));
                foreach (ListItem item in listoftasks.Items)
                {
                    if (item.Value == task_id.ToString())
                    {
                        alreadyThere = true;
                        break;
                    }
                }
                if (!alreadyThere)
                {
                    // adds list items to listbox listoftasks
                    listoftasks.Items.Add(new ListItem(rdr.GetString(1), task_id.ToString()));

                }


            }
            rdr.Close();

            query = "SELECT [story.table].assigned_id FROM [story.table] WHERE [story.table].Id = @storyid";
            myCommand = new SqlCommand(query, myConnection);
            myCommand.Parameters.AddWithValue("@storyid", story_id);
            rdr = myCommand.ExecuteReader();
            while (rdr.Read())
            {
                currentsprint = rdr.GetInt32(0);
            }

            rdr.Close();
            myConnection.Close();

            // sets up connection string to connect to database
            string connectionString1 = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

            // declares sql connection type
            SqlConnection myConnection1 = new SqlConnection(connectionString);

            // opens connection
            myConnection1.Open();

            // query is sent to database
            string query1 = "SELECT [developer.table].*, [user.table].* FROM [developer.table] INNER JOIN [user.table] ON [developer.table].user_id = [user.table].Id WHERE [user.table].Id = @userId AND [developer.table].sprint_id = @sprintid";

            SqlCommand myCommand1 = new SqlCommand(query1, myConnection1);

            // passes variables through paramaters using Session values
            myCommand1.Parameters.AddWithValue("@userId", userid);
            myCommand1.Parameters.AddWithValue("@sprintid", currentsprint);

            // Decalres SqlReader to read from the database 
            SqlDataReader rdr1 = myCommand1.ExecuteReader();
            while (rdr1.Read())
            {

                devId = rdr1.GetInt32(0);

            }

            rdr1.Close();

            // Closes myConnection
            myConnection.Close();

            //Closes myConnection1
            myConnection1.Close();



        }
    }
    protected void assign_Click(object sender, EventArgs e)
    {

        selectedtask = int.Parse(listoftasks.SelectedValue);


        string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;
        SqlConnection myConnection = new SqlConnection(connectionString);
        myConnection.Open();

        string query = "UPDATE [task.table] SET [task.table].dev_id=@userid WHERE [task.table].Id=@Id";

        SqlCommand myCommand = new SqlCommand(query, myConnection);
        myCommand.Parameters.AddWithValue("@Id", selectedtask);
        myCommand.Parameters.AddWithValue("@userid", devId);

        myCommand.ExecuteNonQuery();
        myConnection.Close();

        Response.Redirect("ViewTasks.aspx");
    }

}



        


    

    
