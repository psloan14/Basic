﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
public partial class ViewProject : System.Web.UI.Page
{


    protected void Page_Load(object sender, EventArgs e)
    {
        // makes sure the user is logged
        int user_id = 0;
        if (Session["useridsession"] == null)
        {

            Response.Redirect("Default.aspx");

        }

        else
        {
            user_id = int.Parse(Session["useridsession"].ToString());

        }

        int project_id = int.Parse(Session["current_project"].ToString()); //Takes the id of the project to be displayed
        //ids to know what role has the user in this project
        int developer_id = 0;
        int master_id = 0;
        int owner_id = 0;
        int creator_id = 0;

        //Four database queries to find out what roles the user haves in this project
        string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();

        //Checking if the user is a developer
        string query = "SELECT [developer.table].Id " +
            "FROM [developer.table] INNER JOIN [user.table] ON [user.table].Id = [developer.table].user_id " +
            "INNER JOIN [sprint.table] ON [sprint.table].Id = [developer.table].sprint_id " +
            "INNER JOIN [scrum_master.table] ON [scrum_master.table].Id = [sprint.table].master_id " +
            "INNER JOIN [project.table] ON [project.table].Id = [scrum_master.table].project_id " +
            "WHERE [user.table].Id = @uid AND [project.table].Id = @pid";

        SqlCommand myCommand = new SqlCommand(query, myConnection);

        myCommand.Parameters.AddWithValue("@uid", user_id);
        myCommand.Parameters.AddWithValue("@pid", project_id);

        SqlDataReader rdr = myCommand.ExecuteReader();

        while (rdr.Read())
        {
            if (rdr["Id"] != null)
                developer_id = int.Parse(rdr["Id"].ToString());

        }
        rdr.Close();


        //checking if the user is a scrum master
        query = "SELECT [scrum_master.table].Id FROM [scrum_master.table] INNER JOIN [user.table] ON [user.table].Id = [scrum_master.table].user_id " +
            "INNER JOIN [project.table] ON [project.table].Id = [scrum_master.table].project_id WHERE [user.table].Id = @uid AND [project.table].Id = @pid";

        myCommand = new SqlCommand(query, myConnection);

        myCommand.Parameters.AddWithValue("@uid", user_id);
        myCommand.Parameters.AddWithValue("@pid", project_id);

        rdr = myCommand.ExecuteReader();

        while (rdr.Read())
        {
            if (rdr["Id"] != null)
                master_id = int.Parse(rdr["Id"].ToString());

        }
        rdr.Close();


        //Checking if the user is the product owner
        query = "SELECT [product_owner.table].Id FROM [product_owner.table] INNER JOIN [user.table] ON [user.table].Id = [product_owner.table].user_id " +
            "INNER JOIN [project.table] ON [project.table].Id = [product_owner.table].project_id WHERE [user.table].Id = @uid AND [project.table].Id = @pid";

        myCommand = new SqlCommand(query, myConnection);

        myCommand.Parameters.AddWithValue("@uid", user_id);
        myCommand.Parameters.AddWithValue("@pid", project_id);

        rdr = myCommand.ExecuteReader();

        while (rdr.Read())
        {
            if (rdr["Id"] != null)
                owner_id = int.Parse(rdr["Id"].ToString());

        }
        rdr.Close();


        //checking if the user is the project manager
        query = "SELECT creator_id FROM [project.table] WHERE Id = @pid AND creator_id = @uid";

        myCommand = new SqlCommand(query, myConnection);

        myCommand.Parameters.AddWithValue("@uid", user_id);
        myCommand.Parameters.AddWithValue("@pid", project_id);

        rdr = myCommand.ExecuteReader();

        while (rdr.Read())
        {
            if (rdr["creator_id"] != null)
                creator_id = int.Parse(rdr["creator_id"].ToString());

        }
        rdr.Close();


        //Text to show in webpage what roles the user has. depending on the role, some buttons will become visible.
        string texto = "";

        if (developer_id != 0)
        {
            texto += "developer ";
        }
        if (master_id != 0)
        {
            texto += "SCRUM master ";
            Button3.Visible = true;
        }
        if (owner_id != 0)
        {
            texto += "product owner ";
            Button2.Visible = true;
        }
        if (creator_id != 0)
            texto += "project manager ";


        Role.Text = ("Your role(s) in this project are [ " + texto + "]");


        //Database query to get the product description, start and end date to show it in the webpage
        query = "SELECT productdescription, start_date, end_date FROM [project.table] WHERE Id = @pid";

        DateTime start = new DateTime();
        DateTime end = new DateTime();


        myCommand = new SqlCommand(query, myConnection);
        myCommand.Parameters.AddWithValue("@pid", project_id);
        rdr = myCommand.ExecuteReader();
        while (rdr.Read())
        {
            texto = rdr[0].ToString();
            start = rdr.GetDateTime(1);
            end = rdr.GetDateTime(2);

            if (end.ToShortDateString() == "31/12/9999")
            {
                enddatep.Visible = false;
            }

        }
        
        rdr.Close();
        string start1 = start.ToShortDateString();
        string end1 = end.ToShortDateString();
        Description.Text = texto;
        StartDate.Text = start1;
        EndDate.Text = end1;

        //Database query to get all the sprints in this project and show them in a list
        query = "SELECT [sprint.table].Id, [sprint.table].start_date, [sprint.table].end_date FROM [sprint.table] INNER JOIN [scrum_master.table] ON [sprint.table].master_id = [scrum_master.table].Id " +
            "INNER JOIN [project.table] ON [scrum_master.table].project_id = [project.table].Id WHERE [project.table].Id = @pid";

        myCommand = new SqlCommand(query, myConnection);
        myCommand.Parameters.AddWithValue("@pid", project_id);
        rdr = myCommand.ExecuteReader();

        while (rdr.Read())
        {
            Sprints.Items.Add(new ListItem(rdr[1].ToString() + "-" + rdr[2].ToString(), rdr[0].ToString()));
        }
        rdr.Close();


        //Database query to get the project name and show it in the webpage
        query = "SELECT name FROM [project.table] WHERE Id = @pid";

        myCommand = new SqlCommand(query, myConnection);

        myCommand.Parameters.AddWithValue("@pid", project_id);

        rdr = myCommand.ExecuteReader();

        while (rdr.Read())
        {
            Nombre.Text = rdr[0].ToString();
        }
        rdr.Close();
        myConnection.Close();
    }

    //each time an element of the sprints list is clicked, this method will be called to show that sprint page.
    protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["current_Sprint"] = int.Parse(Sprints.SelectedValue);
        Response.Redirect("Sprint.aspx");
    }


    //This three methods are the three buttons that redirect the user to the different functions he can do in the project
    protected void backlogButton_Click(object sender, EventArgs e)
    { Response.Redirect("ViewProjBacklog.aspx"); }
    protected void editBacklogButton_Click(object sender, EventArgs e)
    { Response.Redirect("AddViewPBacklog.aspx"); }
    protected void newSprintButton_Click(object sender, EventArgs e)
    { Response.Redirect("CreateSprint.aspx"); }

}