﻿using System;
using System.IO;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Drawing;
using System.Text;
using System.Security.Cryptography;

public partial class passwordChange : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void ChangePassword1_ChangedPassword(object sender, EventArgs e)
    {


    }

    protected void Change_Click(object sender, EventArgs e)
    {
        if (CurrentPassword1 != NewPassword1)
        {
            int rowsAffected = 0;
            String query = "UPDATE [user.table] SET Password = @NewPassword WHERE Email = @Email AND Password = @CurrentPassword";
            string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

            SqlConnection myConnection = new SqlConnection(connectionString);

            myConnection.Open();
            {
                using (SqlCommand cmd = new SqlCommand(query))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        SqlCommand myCommand = new SqlCommand(query, myConnection);
                        myCommand.Parameters.AddWithValue("@Email", Email1.Text);
                        myCommand.Parameters.AddWithValue("@CurrentPassword", Encrypt(CurrentPassword1.Text));
                        myCommand.Parameters.AddWithValue("@NewPassword", Encrypt(NewPassword1.Text));
                        myCommand.ExecuteNonQuery();

                        myConnection.Close();
                    }
                    if (rowsAffected > 0)
                    {
                        lblMessage.ForeColor = Color.Green;
                        lblMessage.Text = "Password has been changed.";
                    }
                    else
                    {
                        lblMessage.ForeColor = Color.Red;
                        lblMessage.Text = "Password Changed.";
                    }
                }
            }
        }

        else
        {
            lblMessage.ForeColor = Color.Red;
            lblMessage.Text = "passwords don't match";

        }
        }
    private string Encrypt(string clearText)
    {
        string EncryptionKey = "MAKV2SPBNI99212";
        byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
        using (Aes encryptor = Aes.Create())
        {
            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
            encryptor.Key = pdb.GetBytes(32);
            encryptor.IV = pdb.GetBytes(16);
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(clearBytes, 0, clearBytes.Length);
                    cs.Close();
                }
                clearText = Convert.ToBase64String(ms.ToArray());
            }
        }
        return clearText;
    }

}

