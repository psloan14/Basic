﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Text;

public partial class RegisterUser : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void reg_Click(object sender, EventArgs e)
    {
        string newnme = regname.Text;
        string newpass = regpass.Text;
        string newemail = regemail.Text;
        string newtag = regtags.Text;
        string newdob = regdob.Text;
        string newtowncity = regtowncity.Text;
        string newcountry = regcountry.Text;
        bool role1 = newrole1.Checked;
        bool role2 = newrole2.Checked;
        bool role3 = newrole3.Checked;


        string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();

        string query = "INSERT INTO [user.table] (Name, Password, Email, Dob, TownorCity, Country, Tags, Dev, Owner, Master, Available) VALUES (@nname, @npass, @nemail, @ndob, @ntowncity, @ncountry, @ntag, @nrole1, @nrole2, @nrole3, 1)";

        SqlCommand myCommand = new SqlCommand(query, myConnection);

        myCommand.Parameters.AddWithValue("@nname", newnme);
        myCommand.Parameters.AddWithValue("@npass", Encrypt(newpass));
        myCommand.Parameters.AddWithValue("@nemail", newemail);
        myCommand.Parameters.AddWithValue("@ntag", newtag);
        myCommand.Parameters.AddWithValue("@ndob", newdob);
        myCommand.Parameters.AddWithValue("@ntowncity", newtowncity);
        myCommand.Parameters.AddWithValue("@ncountry", newcountry);
        myCommand.Parameters.AddWithValue("@nrole1", role1);
        myCommand.Parameters.AddWithValue("@nrole2", role2);
        myCommand.Parameters.AddWithValue("@nrole3", role3);


        myCommand.ExecuteNonQuery();
        myConnection.Close();

        


        regname.Text = string.Empty;
        regpass.Text = string.Empty;
        regemail.Text = string.Empty;
        regtags.Text = string.Empty;
        regdob.Text = string.Empty;
        regtowncity.Text = string.Empty;
        regcountry.Text = string.Empty;
        newrole1.Text = string.Empty;
        newrole2.Text = string.Empty;
        newrole3.Text = string.Empty;

        Response.Redirect("Default.aspx");



    }

    private string Encrypt(string clearText)
    {
        string EncryptionKey = "MAKV2SPBNI99212";
        byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
        using (Aes encryptor = Aes.Create())
        {
            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
            encryptor.Key = pdb.GetBytes(32);
            encryptor.IV = pdb.GetBytes(16);
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(clearBytes, 0, clearBytes.Length);
                    cs.Close();
                }
                clearText = Convert.ToBase64String(ms.ToArray());
            }
        }
        return clearText;
    }

    private string Decrypt(string cipherText)
    {
        string EncryptionKey = "MAKV2SPBNI99212";
        byte[] cipherBytes = Convert.FromBase64String(cipherText);
        using (Aes encryptor = Aes.Create())
        {
            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
            encryptor.Key = pdb.GetBytes(32);
            encryptor.IV = pdb.GetBytes(16);
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(cipherBytes, 0, cipherBytes.Length);
                    cs.Close();
                }
                cipherText = Encoding.Unicode.GetString(ms.ToArray());
            }
        }
        return cipherText;
    }


}

