﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class ProjectPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        int userid = 0;
        if (Session["useridsession"] == null)

        {

            Response.Redirect("Default.aspx");

        }

        else
        {
            userid = int.Parse(Session["useridsession"].ToString());
        }

        int project_id = int.Parse(Session["current_project"].ToString()); //Takes the id of the current project

        string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();

        string query = "SELECT [project.table].name FROM [project.table] WHERE [project.table].Id = @Id";

        

      
        SqlCommand myCommand = new SqlCommand(query, myConnection);


        myCommand.Parameters.AddWithValue("@Id", project_id);
        


        SqlDataReader rdr = myCommand.ExecuteReader();

        while (rdr.Read())
        {

            string myprojectName = rdr["name"].ToString();
            ProjectName.Text = myprojectName;

        }

    }



    protected void UpdateStory_Click(object sender, EventArgs e)
    {

        if (IsPostBack)
        {
            storyupdated.Text = "Your story has been added.";
            addStoryText.Visible = false;
        }
        string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();

        string storyDescription = addStoryText.Text;

        int newprojectId = Convert.ToInt32(projectId.Text);
        
        

        string query = "INSERT INTO [story.table] (project_id, description) VALUES (@nproject_id, @ndescription)";

        

        SqlCommand myCommand = new SqlCommand(query, myConnection);

        myCommand.Parameters.AddWithValue("@nproject_id", newprojectId);
        myCommand.Parameters.AddWithValue("@ndescription", storyDescription);

       

        myCommand.ExecuteNonQuery();

        

    }

   

  
}