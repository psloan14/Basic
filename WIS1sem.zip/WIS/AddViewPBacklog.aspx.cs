﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
public partial class EditProductBacklog : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int userid = 0;
        if (Session["useridsession"] == null)
        {

            Response.Redirect("Default.aspx");

        }

        else
        {
            userid = int.Parse(Session["useridsession"].ToString());
        }

        int project_id = int.Parse(Session["current_project"].ToString()); //Takes the id of the current project

        string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        //-----------------------------------------------------------------------------------------------------------------------------------------

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();

        string query = "SELECT [project.table].name FROM [project.table] WHERE [project.table].Id = @Id";

        SqlCommand myCommand = new SqlCommand(query, myConnection);

        myCommand.Parameters.AddWithValue("@Id", project_id);

        SqlDataReader rdr = myCommand.ExecuteReader();

        while (rdr.Read())
        {

            string myprojectName = rdr["name"].ToString();
            ProjectName.Text = myprojectName;

        }
        rdr.Close();
        //Checking if the stories are assigned to a sprint that is over.

        query = "SELECT Id, assigned_id FROM [story.table] WHERE [story.table].project_id = @Id";

        myCommand = new SqlCommand(query, myConnection);

        myCommand.Parameters.AddWithValue("@Id", project_id);

        rdr = myCommand.ExecuteReader();

        while (rdr.Read())
        {
            int story_id = rdr.GetInt32(0);
            try
            {
                int sprint_id = rdr.GetInt32(1);
                if (sprint_id != null)
                {

                    SqlConnection myConnection2 = new SqlConnection(connectionString);

                    myConnection2.Open();

                    string query2 = "SELECT end_date FROM [sprint.table] WHERE Id = @Id";
                    SqlCommand myCommand2 = new SqlCommand(query2, myConnection2);

                    myCommand2.Parameters.AddWithValue("@Id", sprint_id);

                    SqlDataReader rdr2 = myCommand2.ExecuteReader();

                    rdr2.Read();

                    if (rdr2.GetDateTime(0) < DateTime.Now)
                    {
                        query2 = "UPDATE [story.table] SET [story.table].assigned = @assigned WHERE [story.table].Id = @Id";
                        SqlCommand myCommand3 = new SqlCommand(query2, myConnection);

                        myCommand3.Parameters.AddWithValue("@Id", story_id);
                        myCommand3.Parameters.AddWithValue("@assigned", 0);
                    }
                    rdr2.Close();
                }
            }
            catch (System.Data.SqlTypes.SqlNullValueException excp) { }
        }
        rdr.Close();

        myConnection.Close();

        //-----------------------------------------------------------------------------------------------------------------------------------------

        SqlConnection myConnection1 = new SqlConnection(connectionString);

        myConnection1.Open();

        string query1 = "SELECT Id, project_id, description, assigned FROM [story.table] WHERE [story.table].project_id = @Id";

        SqlCommand myCommand1 = new SqlCommand(query1, myConnection1);

        myCommand1.Parameters.AddWithValue("@Id", project_id);

        SqlDataReader rdr1 = myCommand1.ExecuteReader();

        while (rdr1.Read())
        {
            TableCell cell1 = new TableCell();
            TableCell cell2 = new TableCell();

            TextBox txt = new TextBox();
            HyperLink link = new HyperLink();
            link.NavigateUrl = "EditProductBacklog.aspx?id=" + (rdr1.GetInt32(0));

            int project_id1 = (rdr1.GetInt32(1));
            string description = (rdr1.GetString(2));

            cell1.Text = project_id1.ToString();
            if (rdr1.GetInt32(3) != 0)
            {
                cell2.Text = "NOT EDITABLE: " + description.ToString(); // Checks if the story is editable atm
            }
            else
            {
                link.Text = description.ToString();
                cell2.Controls.Add(link);
            }

            TableRow row = new TableRow();

            
            
            row.Cells.Add(cell2);

            storytable.Rows.Add(row);

        }
        rdr1.Close();
        myConnection1.Close();

    }

    protected void UpdateStory_Click(object sender, EventArgs e)
    {


        int project_id = int.Parse(Session["current_project"].ToString());
        string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();

        string storyDescription = addStoryText.Text;

        string query = "INSERT INTO [story.table] (project_id, description) VALUES (@nproject_id, @ndescription)";

        SqlCommand myCommand = new SqlCommand(query, myConnection);

        myCommand.Parameters.AddWithValue("@nproject_id", project_id);
        myCommand.Parameters.AddWithValue("@ndescription", storyDescription);

        myCommand.ExecuteNonQuery();

        Response.Redirect("AddViewPBacklog.aspx");

    }




   
}

  