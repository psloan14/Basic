﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Sprint : System.Web.UI.Page
{
    private static int sessionId = 0;
    private static int idSprint = 0;
    private static int ownerId = 0;
    private static int owner_Id = 0;
    private static int masterId = 0;
    private static int master_Id = 0;
    protected void Page_Load(object sender, EventArgs e)
    {

        // makes sure the user is logged
        sessionId = 0;
        if (Session["useridsession"] == null)
        {

            Response.Redirect("Default.aspx");

        }

        else
        {
            sessionId = int.Parse(Session["useridsession"].ToString());

        }

        masterId = int.Parse(Session["useridsession"].ToString());

        // sets up connection string to connect to database
        string connectionString4 = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        // declares sql connection type
        SqlConnection myConnection4 = new SqlConnection(connectionString4);

        // opens connection
        myConnection4.Open();

        // query is sent to database
        string query4 = "SELECT [scrum_master.table].*, [user.table].* FROM [scrum_master.table] INNER JOIN [user.table] ON [scrum_master.table].user_id = [user.table].Id WHERE [scrum_master.table].user_id = @userId";


        SqlCommand myCommand4 = new SqlCommand(query4, myConnection4);

        // passes variables through paramaters using Session values
        myCommand4.Parameters.AddWithValue("@userId", masterId);
        

        // Decalres SqlReader to read from the database 
        SqlDataReader rdr4 = myCommand4.ExecuteReader();
        while (rdr4.Read())
        {
            // reads the value of column "Master" and assigns it to string
            string id_Master = rdr4["user_id"].ToString();
            int new_Master = Convert.ToInt32(id_Master);
            master_Id = new_Master;
        }

        int master = Convert.ToInt32(master_Id);

        // Checks if "Master" column value = 0 and is not assigned a scrum master
        if (master == masterId)
        {
            AssignProductBacklogBttn.Visible = true;
        }

        // Closes reader
        rdr4.Close();

        // Closes connection
        myConnection4.Close();

        //////////////////////////////////////////////////////////////////////////////////////////////////////////
        ownerId = int.Parse(Session["useridsession"].ToString());
        
             // sets up connection string to connect to database
        string connectionString3 = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        // declares sql connection type
        SqlConnection myConnection3 = new SqlConnection(connectionString3);

        // opens connection
        myConnection3.Open();

        // query is sent to database
        string query3 = "SELECT [product_owner.table].* FROM [product_owner.table] WHERE [product_owner.table].user_id = @productOwnerId";


        SqlCommand myCommand3 = new SqlCommand(query3, myConnection3);

        // passes variables through paramaters using Session values
        
        myCommand3.Parameters.AddWithValue("@productOwnerId", ownerId);

        // Decalres SqlReader to read from the database 
        SqlDataReader rdr3 = myCommand3.ExecuteReader();
        while (rdr3.Read())
        {
            // reads the value of column "Master" and assigns it to string
            string id_Owner = rdr3["user_id"].ToString();
            int new_Owner = Convert.ToInt32(id_Owner);
            owner_Id = new_Owner;
        }

        int owner = Convert.ToInt32(owner_Id);

        // Checks if "Master" column value = 0 and is not assigned a scrum master
        if (owner == ownerId)
        {
            RateDevelopers.Visible = false;
            ViewSprintBacklog.Visible = false;
            

        }

        // Closes reader
        rdr3.Close();

        // Closes connection
        myConnection3.Close();

   //////////////////////////////////////////////////////////////////////////////////////////////////////////

        //takes the current sprintid, to know what sprint should be shown
        idSprint = (int)Session["current_Sprint"];


        string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();

        //Database query that searches for the sprint data
        string query = "SELECT [sprint.table].start_date, [sprint.table].end_date, [user.table].Name FROM [sprint.table] INNER JOIN [scrum_master.table] ON [scrum_master.table].Id = [sprint.table].master_id INNER JOIN [user.table] ON [user.table].Id = [scrum_master.table].user_id WHERE [sprint.table].Id=@sprint_id";

        SqlCommand myCommand = new SqlCommand(query, myConnection);
        myCommand.Parameters.AddWithValue("@sprint_id", idSprint);

        SqlDataReader rdr = myCommand.ExecuteReader();

        //Displays in the webpage the sprint data
        while (rdr.Read())
        {
            string startdate = rdr["start_date"].ToString();
            string enddate = rdr["end_date"].ToString();
            string scrummaster = rdr["Name"].ToString();

            sprintdatelabel.Text = startdate + " until " + enddate;
            scrummasterlabel.Text = scrummaster;


        }
        rdr.Close();

        //Database query that searches for the developers involved in this sprint
        query = "SELECT [user.table].Name FROM [user.table] INNER JOIN [developer.table] ON [user.table].Id = [developer.table].user_id INNER JOIN [sprint.table] ON [developer.table].sprint_id = [sprint.table].Id WHERE [sprint.table].Id=@sprint_id";

        myCommand = new SqlCommand(query, myConnection);
        myCommand.Parameters.AddWithValue("@sprint_id", idSprint);

        SqlDataReader rdr2 = myCommand.ExecuteReader();

        //Shows the developers in a list
        while (rdr2.Read())
        {
            developerslist.Items.Add(new ListItem(rdr2.GetString(0)));
        }
        rdr2.Close();

        // sets up connection string to connect to the database
        string connectionString1 = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        //Declaring a new SQL Connection type and opens a new connection
        SqlConnection myConnection1 = new SqlConnection(connectionString1);

        myConnection1.Open();

        int sprint_Id = (int)Session["current_Sprint"];

        //Searches the Sprint table in the database that will use the end date to display the button.
        string query1 = "SELECT [sprint.table].Id, [sprint.table].end_date FROM [sprint.table] WHERE [sprint.table].Id = @sprint_Id";

        SqlCommand myCommand1 = new SqlCommand(query1, myConnection1);
        myCommand1.Parameters.AddWithValue("@sprint_Id", sprint_Id);

        SqlDataReader rdr1 = myCommand1.ExecuteReader();

        //Checks to see if the Current Sprint has ended, if it has ended then the button labled RateDevelopers will display only allowing the Scrum Master to click on it and be directed to the Rate Developers page.
        DateTime dateNow = DateTime.Now;
        // DateTime end1 = new DateTime(2015, 12, 02);



        while (rdr1.Read())
        {
            DateTime end = rdr1.GetDateTime(1);
            if ((DateTime.Compare(end, dateNow) < 0))
            {
                RateDevelopers.Visible = true;
            }
        }
        //Closes the reader
        rdr1.Close();

    }


    protected void back_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewProject.aspx");
    }
    protected void AssignProductBacklogBttn_Click(object sender, EventArgs e)
    {
        Session["current_Sprint"] = idSprint;
        Response.Redirect("AssignSprintBacklog.aspx");
    }

    protected void RateDevelopers_Click(object sender, EventArgs e)
    {
        Response.Redirect("DeveloperRatings.aspx");

    }
    protected void ViewSprintBacklog_Click(object sender, EventArgs e)
    {

        Session["current_Sprint"] = idSprint;
        Response.Redirect("SprintBacklog.aspx");
    }


    protected void burndown_Click(object sender, EventArgs e)
    {
        Session["current_Sprint"] = idSprint;
        Response.Redirect("BurndownChart.aspx");
    }
}