﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Home : System.Web.UI.Page
{
    private int project_id;
//----------------------------------------------------------------------------------------------------------------------------------------------    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            int row = 0;
            if (Session["useridsession"] == null)
            {

                Response.Redirect("Default.aspx");

            }

            else
            {
                row = int.Parse(Session["useridsession"].ToString());
            }


            string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

            SqlConnection myConnection = new SqlConnection(connectionString);

            myConnection.Open();



            string query = "SELECT [user.table].Id, [project.table].*, [developer.table].*, [sprint.table].*, [scrum_master.table].* FROM [project.table] INNER JOIN [scrum_master.table] ON [scrum_master.table].project_id = [project.table].Id INNER JOIN [sprint.table] ON [sprint.table].master_id = [scrum_master.table].Id INNER JOIN [developer.table] ON [developer.table].sprint_id = [sprint.table].Id INNER JOIN [user.table] ON [user.table].Id = [developer.table].user_id WHERE [user.table].Id =@Id";

            SqlCommand myCommand = new SqlCommand(query, myConnection);

            myCommand.Parameters.AddWithValue("@Id", row);


            SqlDataReader rdr = myCommand.ExecuteReader();
            ProjectList.Items.Clear();
            while (rdr.Read())
            {
                project_id = (rdr.GetInt32(1));
                bool alreadyThere = false;
                foreach (ListItem item in ProjectList.Items)
                {
                    if (item.Value == project_id.ToString())
                    {
                        alreadyThere = true;
                        break;
                    }
                }
                if (!alreadyThere)
                {
                    ProjectList.Items.Add(new ListItem(rdr.GetString(2), project_id.ToString()));
                }




            }
            rdr.Close();
            query = "SELECT [project.table].* FROM [project.table] INNER JOIN [product_owner.table] ON [product_owner.table].project_id = [project.table].Id WHERE [product_owner.table].user_id = @id";
            myCommand = new SqlCommand(query, myConnection);

            myCommand.Parameters.AddWithValue("@id", row);

            rdr = myCommand.ExecuteReader();
            while (rdr.Read())
            {
                project_id = (rdr.GetInt32(0));
                bool alreadyThere = false;
                foreach (ListItem item in ProjectList.Items)
                {
                    if (item.Value == project_id.ToString())
                    {
                        alreadyThere = true;
                        break;
                    }
                }
                if (!alreadyThere)
                {
                    ProjectList.Items.Add(new ListItem(rdr.GetString(1), project_id.ToString()));
                }

            }
            rdr.Close();


            query = "SELECT [project.table].* FROM [project.table] WHERE creator_id = @id";
            myCommand = new SqlCommand(query, myConnection);

            myCommand.Parameters.AddWithValue("@id", row);

            rdr = myCommand.ExecuteReader();
            while (rdr.Read())
            {
                project_id = (rdr.GetInt32(0));
                bool alreadyThere = false;
                foreach (ListItem item in ProjectList.Items)
                {
                    if (item.Value == project_id.ToString())
                    {
                        alreadyThere = true;
                        break;
                    }
                }
                if (!alreadyThere)
                {
                    ProjectList.Items.Add(new ListItem(rdr.GetString(1), project_id.ToString()));
                }

            }
            rdr.Close();



            query = "SELECT [project.table].* FROM [project.table] INNER JOIN [scrum_master.table] ON [scrum_master.table].project_id = [project.table].Id WHERE [scrum_master.table].user_id = @id";
            myCommand = new SqlCommand(query, myConnection);

            myCommand.Parameters.AddWithValue("@id", row);

            rdr = myCommand.ExecuteReader();
            while (rdr.Read())
            {
                project_id = (rdr.GetInt32(0));
                bool alreadyThere = false;
                foreach (ListItem item in ProjectList.Items)
                {
                    if (item.Value == project_id.ToString())
                    {
                        alreadyThere = true;
                        break;
                    }
                }
                if (!alreadyThere)
                {
                    ProjectList.Items.Add(new ListItem(rdr.GetString(1), project_id.ToString()));
                }
            }
            rdr.Close();
            {

                string query1 = "SELECT Name, Dob, TownorCity, Country, Tags FROM [user.table] WHERE Id=@Id";

                SqlCommand myCommand1 = new SqlCommand(query1, myConnection);

                myCommand1.Parameters.AddWithValue("@Id", row);

                SqlDataReader rdr1 = myCommand1.ExecuteReader();

                while (rdr1.Read())
                {
                    string disname = rdr1["Name"].ToString();
                    displayname.Text = disname;

                    string disdob = rdr1["Dob"].ToString();
                    displaydob.Text = disdob;

                    string distowncity = rdr1["TownorCity"].ToString();
                    displaytowncity.Text = distowncity;

                    string discountry = rdr1["Country"].ToString();
                    displaycountry.Text = discountry;

                    string distags = rdr1["Tags"].ToString();
                    displaytags.Text = distags;

                }


            }
            rdr.Close();

        }

        
        

    }
    //----------------------------------------------------------------------------------------------------------------------------------------------
    
    //---------------------------------------------------------------------------------------------------------------------------------------------- 
    protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["current_project"] = int.Parse(ProjectList.SelectedValue);
        Response.Redirect("ViewProject.aspx");
    }
    //---------------------------------------------------------------------------------------------------------------------------------------------- 

    
}