﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class CreateSprint : System.Web.UI.Page
{

    //results is a list of developers found
    private static List<Tuple<int, string>> results = new List<Tuple<int, string>>();
    private static int masterId = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        masterId = 0;
        // makes sure the user is logged
        if (Session["useridsession"] == null)
        {

            Response.Redirect("Default.aspx");

        }

        else
        {
            masterId = int.Parse(Session["useridsession"].ToString());

        }
    }

    //method executed when the search for developers is started(press the button)
    protected void Searchfordevs_Click(object sender, EventArgs e)
    {
        if (Calendar1.SelectedDate == DateTime.MinValue || Calendar2.SelectedDate == DateTime.MinValue || Calendar1.SelectedDate > Calendar2.SelectedDate)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "alert('Invalid dates selected');", true);
            return;
        }
        //cleans the lists in each new search
        developerslist.Items.Clear();
        results.Clear();

        //gets the tags the user wrote
        string searchdata = SearchDevs.Text;

        string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();
        //query to find developers matching the criterion.
        string query = "SELECT Id, Email FROM [user.table] WHERE Dev=1 AND Tags = @searchdata";

        SqlCommand myCommand = new SqlCommand(query, myConnection);

        myCommand.Parameters.AddWithValue("@searchdata", searchdata);
        SqlDataReader rdr = myCommand.ExecuteReader();

        //stores the results in a list for later use.
        while (rdr.Read())
        {
            results.Add(new Tuple<int, string>(rdr.GetInt32(0), rdr.GetString(1)));
        }
        rdr.Close();
        //displays the results in a list
        foreach (Tuple<int, string> item in results)
        {
            ListItem a = new ListItem(item.Item2);
            query = "SELECT [sprint.table].start_date, [sprint.table].end_date FROM [sprint.table] "+ 
                "INNER JOIN [developer.table] ON [developer.table].sprint_id = [sprint.table].Id WHERE [developer.table].user_id = @user_id";

            myCommand = new SqlCommand(query, myConnection);

            myCommand.Parameters.AddWithValue("@user_id", item.Item1);
            rdr = myCommand.ExecuteReader();
            bool available = true;
            while (rdr.Read()){
                DateTime start = rdr.GetDateTime(0);
                DateTime end = rdr.GetDateTime(1);
                if ((DateTime.Compare(start, Calendar1.SelectedDate) <= 0 && DateTime.Compare(end, Calendar1.SelectedDate) > 0) || (DateTime.Compare(start, Calendar1.SelectedDate) >= 0 && DateTime.Compare(start, Calendar2.SelectedDate) <= 0))
                {
                    available = false;
                }
            }
            if(!available)
                a.Text = a.Text + " NOT AVAILABLE IN THOSE DATES";
            developerslist.Items.Add(a);
            rdr.Close();
            
        }

        CreateSprintButton.Visible = true;
        
    }


    protected void CreateSprintButton_Click(object sender, EventArgs e)
    {
        //gets the user id(since the user is in this page, is a scrummaster
        int userMasterid = int.Parse(Session["useridsession"].ToString());
        int projectId = int.Parse(Session["current_project"].ToString());

        //Checks for incoherent dates and makes sure that at least 1 developer is selected
        if (Calendar1.SelectedDate == DateTime.MinValue || Calendar2.SelectedDate == DateTime.MinValue || Calendar1.SelectedDate > Calendar2.SelectedDate)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "alert('Invalid dates selected');", true);
            return;
        }
        if (developerslist.SelectedItem == null)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "alert('Select at least one developer');", true);
            return;
        }

        
        string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();

        string query = "SELECT start_date, end_date FROM [project.table] WHERE Id = @project";
        SqlCommand myCommand = new SqlCommand(query, myConnection);
        myCommand.Parameters.AddWithValue("@project", projectId);

        SqlDataReader rdr2 = myCommand.ExecuteReader();
        rdr2.Read();
        DateTime start_project = rdr2.GetDateTime(0);
        DateTime end_project = rdr2.GetDateTime(1);
        rdr2.Close();

        if (Calendar1.SelectedDate < start_project || Calendar2.SelectedDate > end_project)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "alert('Selected dates are out of the project');", true);
            return;
        }

        //search for the scrumMaster Id (the Id the user has in the scrum master table)
        query = "SELECT Id FROM [scrum_master.table] WHERE user_id=@masterId AND project_id = @project";

        myCommand = new SqlCommand(query, myConnection);
        myCommand.Parameters.AddWithValue("@masterId", userMasterid);
        myCommand.Parameters.AddWithValue("@project", projectId);

        rdr2 = myCommand.ExecuteReader();
        rdr2.Read();
        int id_master = rdr2.GetInt32(0);
        rdr2.Close();

        //creates the sprint in the database
        query = "INSERT INTO [sprint.table](master_id, start_date, end_date) VALUES (@masterId, @startdate, @enddate)";

        myCommand = new SqlCommand(query, myConnection);
        myCommand.Parameters.AddWithValue("@masterId", id_master);
        myCommand.Parameters.AddWithValue("@startdate", Calendar1.SelectedDate);
        myCommand.Parameters.AddWithValue("@enddate", Calendar2.SelectedDate);

        myCommand.ExecuteNonQuery();


        //recovers the new sprint's Id
        query = "SELECT Id FROM [sprint.table] WHERE master_id=@masterId AND start_date=@startdate AND end_date=@enddate";

        myCommand = new SqlCommand(query, myConnection);
        myCommand.Parameters.AddWithValue("@masterId", id_master);
        myCommand.Parameters.AddWithValue("@startdate", Calendar1.SelectedDate);
        myCommand.Parameters.AddWithValue("@enddate", Calendar2.SelectedDate);
    
        SqlDataReader rdr = myCommand.ExecuteReader();
        rdr.Read();
        int id_sprint = rdr.GetInt32(0);
        rdr.Close();



        //this loops creates a new entry in the developer table for each developer in the list
        foreach (ListItem item in developerslist.Items)
        {

            if (item.Selected)
            {
                int id_user = 0;
                //searching for the Id of the selected developers in the list where it had been previously stored
                foreach (Tuple<int, string> thing in results)
                {

                    if (thing.Item2 == item.Value)
                    {
                        id_user = thing.Item1;
                        break;
                    }
                }

                //creates the new row in the developer table
                if (id_user != 0)
                {
                    string query2 = "INSERT INTO [developer.table](user_id, sprint_id) VALUES (@user, @sprint)";

                    SqlCommand myCommand1 = new SqlCommand(query2, myConnection);

                    myCommand1.Parameters.AddWithValue("@user", id_user);
                    myCommand1.Parameters.AddWithValue("@sprint", id_sprint);
                    myCommand1.ExecuteNonQuery();
                }

            }
        }

        myConnection.Close();
        Session["current_Sprint"] = id_sprint;
        Response.Redirect("Sprint.aspx");
        
    }
}