﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class updatestory : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int row = 0;
        if (Request.QueryString["storyID"] != null)
        {
            //if it does exist in URL then do this...
            row = int.Parse(Request.QueryString["storyID"]);
        }
        else
        {
            //if there is no querystring in URL then redirect page...
            Response.Redirect("Home.aspx");
        }

        // set-up object to use the web.config file
        string connectionString = WebConfigurationManager.ConnectionStrings
        ["scrumconnection"].ConnectionString;

        //set-up connection object called 'myConnection'
        SqlConnection myConnection = new SqlConnection(connectionString);

        //open database communication
        myConnection.Open();

        //create the SQL statement
        string query = "SELECT * FROM [story.table] WHERE Id=@rowid";

        //set-up SQL command and use the SQL and myConnection object
        SqlCommand myCommand = new SqlCommand(query, myConnection);
        //create a parameterised object
        myCommand.Parameters.AddWithValue("rowid", row);

        //create a sqldatareader object that asks for data from a table
        SqlDataReader rdr = myCommand.ExecuteReader();


        //when in read mode ask for data
        while (rdr.Read())
        {
            //put field data from 'description' into variable
            string mystory = rdr["description"].ToString();
            //put variable value into textbox storytext
            userstorytext.Text = mystory;


        }



    }

    protected void DeleteStory_Click(object sender, EventArgs e)
    {

        if (IsPostBack)
        {
            commentdeleted.Text = "You have deleted this story.";
            userstorytext.Visible = false;
        }

        // set-up object to use the web.config file
        string connectionString = WebConfigurationManager.ConnectionStrings
        ["scrumconnection"].ConnectionString;

        // set-up connection object called 'myConnection'
        SqlConnection myConnection = new SqlConnection(connectionString);

        // open database communication
        myConnection.Open();

        int row = int.Parse(Request.QueryString["storyID"]);

        string query = null;

        query = "DELETE FROM [story.table] WHERE Id =@id";


        SqlCommand myCommand = new SqlCommand(query, myConnection);
        //create a parameterised object

        myCommand.Parameters.AddWithValue("@id", row);

        myCommand.ExecuteNonQuery();

        myConnection.Close();

        commentdeleted.Text = "Your story has been Deleted!";


    }
    protected void UpdateStory_Click(object sender, EventArgs e)
    {
         // set-up object to use the web.config file
        string connectionString = WebConfigurationManager.ConnectionStrings
        ["scrumconnection"].ConnectionString;

        // set-up connection object called 'myConnection'
        SqlConnection myConnection = new SqlConnection(connectionString);

        // open database communication
        myConnection.Open();

        string storynametextupdate = userstorytext.Text;

        // retrieves the Id of the user story and put it into a variable storyid
        int storyid = int.Parse(Request.QueryString["storyID"]);


        string query = null;
        
        query = "UPDATE [story.table] SET [story.table].description = @descriptionnew WHERE [story.table].Id = @Id";


        SqlCommand myCommand = new SqlCommand(query, myConnection);

        //create a parameterised object
        myCommand.Parameters.AddWithValue("@Id", storyid);
        myCommand.Parameters.AddWithValue("@descriptionnew", storynametextupdate);

        myCommand.ExecuteNonQuery();

        myConnection.Close();


    }
}
 

       