﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;


public partial class ProjectCreation : System.Web.UI.Page
{


    private static List<Tuple<int, string>> results = new List<Tuple<int, string>>();
    private static List<Tuple<int, string>> results2 = new List<Tuple<int, string>>();
    private static int CreatorId = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            CreatorId = 0;

            // Makes sure the user is logged in

            if (Session["useridsession"] == null)
            {

                Response.Redirect("Default.aspx");

            }

            else
            {
                CreatorId = int.Parse(Session["useridsession"].ToString());

            }
        }


    }




    // Results is a list of Owners found
    protected void SearchForOwners_Click(object sender, EventArgs e)
    {
        results2.Clear();
        Ownerslist.Items.Clear();
        string searchdata = searchOwner.Text;

        string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();

        string query = "SELECT Id, Email FROM [user.table] WHERE Owner=1 AND Available=1 AND Name = @searchdata OR Email = @searchdata";

        SqlCommand myCommand = new SqlCommand(query, myConnection);

        myCommand.Parameters.AddWithValue("@searchdata", searchdata);
        SqlDataReader rdr = myCommand.ExecuteReader();
        while (rdr.Read())
        {
            results2.Add(new Tuple<int, string>(rdr.GetInt32(0), rdr.GetString(1)));
        }
        foreach (Tuple<int, string> item in results2)
        {
            Ownerslist.Items.Add(new ListItem(item.Item2));
        }

        searchForOwners.Visible = true;

    }


    // Results is a list of Scrum Masters found
    protected void searchForScrums_Click(object sender, EventArgs e)
    {
        results.Clear();
        scrumsList.Items.Clear();
        string searchdata = searchScrum.Text;

        string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();

        string query = "SELECT Id, Email FROM [user.table] WHERE Master=1 AND Available=1 AND Name = @searchdata OR Email = @searchdata";

        SqlCommand myCommand = new SqlCommand(query, myConnection);

        myCommand.Parameters.AddWithValue("@searchdata", searchdata);
        SqlDataReader rdr = myCommand.ExecuteReader();
        while (rdr.Read())
        {
            results.Add(new Tuple<int, string>(rdr.GetInt32(0), rdr.GetString(1)));
        }
        foreach (Tuple<int, string> item2 in results)
        {
            scrumsList.Items.Add(new ListItem(item2.Item2));
        }

        searchForScrums.Visible = true;
    }

    protected void Page_Create(object sender, EventArgs e)
    {

        DateTime enddate;
        // Checks to make sure dates are suitable and ensures atleast one Owner and Scrum Master have been selected

        if (Calendar2.SelectedDate != DateTime.MinValue)
        {
            enddate = Calendar2.SelectedDate;
            if (Calendar1.SelectedDate > Calendar2.SelectedDate)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "alert('Invalid dates selected');", true);
                return;
            }
        }
        else
        {
            enddate = new DateTime(9999, 12, 31);
        }
        if (Calendar1.SelectedDate == DateTime.MinValue)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "alert('Please Select a start date');", true);
            return;
        }

        if (Ownerslist.SelectedItem == null)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "alert('Select at least Owner for project');", true);
            return;
        }
        if (scrumsList.SelectedItem == null)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "alert('Select one Scrum Master for Project');", true);
            return;
        }




        // Gets the user id(since the user is in this page, is a project creator )

        int userCreatorid = int.Parse(Session["useridsession"].ToString());


        string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();


        string newProjectName = projectName.Text;
        string newProjectDesc = ProjectDescription.Text;
        int id_creator = int.Parse(Session["useridsession"].ToString());


        // This loops creates a new entry in the product_owners table for each owner in the list
        int id_user = 0;
        foreach (ListItem item in Ownerslist.Items)
        {

            if (item.Selected)
            {


                // Searching for the Id of the selected owners in the list where it had been previously stored

                foreach (Tuple<int, string> thing in results2)
                {

                    if (thing.Item2 == item.Value)
                    {
                        id_user = thing.Item1;
                        Session["id_owner"] = id_user;
                        break;
                    }

                }
            }
        }
        //creates the project in the database

        string query = "INSERT INTO [project.table](creator_id, name, start_date, end_date, productdescription, owner_id) VALUES (@creatorId, @name, @startdate, @enddate, @productdescription, @owner_id)";

        SqlCommand myCommand = new SqlCommand(query, myConnection);
        myCommand.Parameters.AddWithValue("@creatorId", id_creator);
        myCommand.Parameters.AddWithValue("@name", newProjectName);
        myCommand.Parameters.AddWithValue("@startdate", Calendar1.SelectedDate);
        myCommand.Parameters.AddWithValue("@enddate", enddate);
        myCommand.Parameters.AddWithValue("@productdescription", newProjectDesc);
        myCommand.Parameters.AddWithValue("@owner_id", id_user);

        myCommand.ExecuteNonQuery();



        query = "SELECT Id FROM [project.table] WHERE creator_id=@creatorId AND start_date=@startdate AND end_date=@enddate";

        myCommand = new SqlCommand(query, myConnection);
        myCommand.Parameters.AddWithValue("@creatorId", id_creator);
        myCommand.Parameters.AddWithValue("@startdate", Calendar1.SelectedDate);
        myCommand.Parameters.AddWithValue("@enddate", enddate);


        SqlDataReader rdr = myCommand.ExecuteReader();
        rdr.Read();
        int id_project = rdr.GetInt32(0);
        rdr.Close();

        
            // Creates the new row in the product_owner table

            string query1 = "INSERT INTO [product_owner.table](user_id, project_id) VALUES (@user, @project)";


            SqlCommand myCommand1 = new SqlCommand(query1, myConnection);

            myCommand1.Parameters.AddWithValue("@user", id_user);
            myCommand1.Parameters.AddWithValue("@project", id_project);
            myCommand1.ExecuteNonQuery();

       


        // This loops creates a new entry in the scrum_master table for each scrum master in the list

        foreach (ListItem item2 in scrumsList.Items)
        {

            if (item2.Selected)
            {
                int id_user2 = 0;

                // Searching for the Id of the selected scrum masters in the list where it had been previously stored

                foreach (Tuple<int, string> thing in results)
                {

                    if (thing.Item2 == item2.Value)
                    {
                        id_user2 = thing.Item1;
                        Session["id_scrum"] = id_user2;
                        break;
                    }
                }



                // Creates the new row in the scrum_master table

                string query2 = "INSERT INTO [scrum_master.table](user_id, project_id) VALUES (@user, @project)";


                SqlCommand myCommand2 = new SqlCommand(query2, myConnection);

                myCommand2.Parameters.AddWithValue("@user", id_user2);
                myCommand2.Parameters.AddWithValue("@project", id_project);
                myCommand2.ExecuteNonQuery();

                


            }
        }
        string query3 = "UPDATE [project.table] SET [project.table].owner_id = @newowner_id WHERE [project.table].Id = @Id";

        SqlCommand myCommand3 = new SqlCommand(query3, myConnection);

        myCommand3.Parameters.AddWithValue("@newowner_id", id_user);
        myCommand3.Parameters.AddWithValue("@Id", id_project);
        myCommand3.ExecuteNonQuery();

        myConnection.Close();
        Session["current_Project"] = id_project;
        Response.Redirect("ViewProject.aspx");







    }
}
