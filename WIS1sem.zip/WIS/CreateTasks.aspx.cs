﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class CreateTasks : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void create_Click(object sender, EventArgs e)
    {
        string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();

        int story_id = int.Parse(Session["current_story"].ToString()); //Takes the id of the current story
        string updatehours = hourstb.Text;
        string updatedesc = descriptiontb.Text;

        string query = "INSERT INTO [task.table] (hours_left, blocked, description, story_id) VALUES (@newhours, 0, @newdesc, @story_id)";

        SqlCommand myCommand = new SqlCommand(query, myConnection);

        myCommand.Parameters.AddWithValue("@newhours", updatehours);
        myCommand.Parameters.AddWithValue("@newdesc", updatedesc);
        myCommand.Parameters.AddWithValue("@story_id", story_id);

        myCommand.ExecuteNonQuery();

        myConnection.Close();

        Response.Redirect("ViewTasks.aspx");
    }
}