﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class profile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            int row = 0;
            if (Session["useridsession"] == null)
            {

                Response.Redirect("Default.aspx");

            }


            else
            {
                row = int.Parse(Session["useridsession"].ToString());
            }

            string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

            SqlConnection myConnection = new SqlConnection(connectionString);

            myConnection.Open();



            string query = "SELECT Name, Dob, TownorCity, Country, Tags FROM [user.table] WHERE Id=@Id";

            SqlCommand myCommand = new SqlCommand(query, myConnection);

            myCommand.Parameters.AddWithValue("@Id", row);

            SqlDataReader rdr = myCommand.ExecuteReader();

            while (rdr.Read())
            {
                string disname = rdr["Name"].ToString();
                displayname.Text = disname;

                string disdob = rdr["Dob"].ToString();
                displaydob.Text = disdob;

                string distowncity = rdr["TownorCity"].ToString();
                displaytowncity.Text = distowncity;

                string discountry = rdr["Country"].ToString();
                displaycountry.Text = discountry;

                string distags = rdr["Tags"].ToString();
                displaytags.Text = distags;

            }




        }
    }
    protected void updateinfo_Click(object sender, EventArgs e)
    {
        string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();

        string updatedusername = displayname.Text;
        string updateddob = displaydob.Text;
        string updatedtowncity = displaytowncity.Text;
        string updatedcountry = displaycountry.Text;
        string updatedtags = displaytags.Text;
        int row = int.Parse(Session["useridsession"].ToString());

        string query = "UPDATE [user.table] SET Name=@newname, Dob=@newdob, TownorCity=@newtowncity, Country=@newcountry, tags=@newtag WHERE Id=@Id";

        SqlCommand myCommand = new SqlCommand(query, myConnection);

        myCommand.Parameters.AddWithValue("@newname", updatedusername);
        myCommand.Parameters.AddWithValue("@newdob", updateddob);
        myCommand.Parameters.AddWithValue("@newtowncity", updatedtowncity);
        myCommand.Parameters.AddWithValue("@newcountry", updatedcountry);
        myCommand.Parameters.AddWithValue("@newtag", updatedtags);
        myCommand.Parameters.AddWithValue("@Id", row);

        myCommand.ExecuteNonQuery();

        myConnection.Close();

        txt.Text = "Your information has now been updated.";

        

    }
  
    protected void projectspage_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
}

