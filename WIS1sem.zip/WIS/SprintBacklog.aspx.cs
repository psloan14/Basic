﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class SprintBacklog : System.Web.UI.Page
{
    // Declares a private int
    private int story_id;

    // Declares an array of tuples to store a list of results fro database
    private static List<Tuple<int, string>> results = new List<Tuple<int, string>>();

    // Declares a private static int
    private static int masterId = 0;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            sprintBacklogL.ClearSelection();
           
            int sprintId = 0;

            // Checks if the Session for current_sprint has been set
            if (Session["current_Sprint"] != null)
            {
                // If session has been set then it will be assigned to sprintId
                sprintId = (int)Session["current_Sprint"];
            }
            else
            {
                // If the session is not set then web app will redirect back to homepage
                Response.Redirect("Home.aspx");
            }

            // parses the Session "current_project" to the variable project_id
            int projectId = int.Parse(Session["current_project"].ToString());

            // Clears the list results
            results.Clear();

            // Cleares the
            sprintBacklogL.Items.Clear();

            // sets up connection string to connect to database
            string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

            // declares sql connection type
            SqlConnection myConnection = new SqlConnection(connectionString);

            // opens connection
            myConnection.Open();

            // query is sent to database
            // CHANGED QUERY SO THAT ONLY STORIES THAT HAVE BEEN ASSIGNED TO CURRENT SPRINT BACKLOG ARE VISIBLE 

            string query = "SELECT [story.table].Id, description FROM [story.table] WHERE [story.table].project_id = @projectId AND [story.table].assigned_id = @sprint AND assigned = 1";


            SqlCommand myCommand = new SqlCommand(query, myConnection);

            // passes variables through paramaters using Session values
            myCommand.Parameters.AddWithValue("@projectId", projectId);
            myCommand.Parameters.AddWithValue("@sprint", sprintId);

            // Decalres SqlReader to read from the database 
            SqlDataReader rdr = myCommand.ExecuteReader();

            // Clears items in listbox sprintBacklog
            sprintBacklogL.Items.Clear();
            while (rdr.Read())
            {
                bool alreadyThere = false;
                story_id = (rdr.GetInt32(0));
                foreach (ListItem item in sprintBacklogL.Items)
                {
                    if (item.Value == story_id.ToString())
                    {
                        alreadyThere = true;
                        break;
                    }
                }
                if (!alreadyThere)
                {
                    // adds list items to listbox sprintBacklog
                    sprintBacklogL.Items.Add(new ListItem(rdr.GetString(1), story_id.ToString()));
                }


            }

            // Checks if Session useridession is not assigned
            if (Session["useridsession"] == null)
            {
                // If not assigned then redirect webapp
                Response.Redirect("Default.aspx");

            }

            else
            {
                // If useridession is assigned then parse it to variable masterId
                masterId = int.Parse(Session["useridsession"].ToString());


            }



            // parses the Session "current_project" to the variable project_id
            int project_id = int.Parse(Session["current_project"].ToString());

            // sets up connection string to connect to database
            string connectionString1 = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

            // declares sql connection type
            SqlConnection myConnection1 = new SqlConnection(connectionString);

            // opens connection
            myConnection1.Open();

            // query is sent to database
            string query1 = "SELECT [scrum_master.table].*, [user.table].* FROM [scrum_master.table] INNER JOIN [user.table] ON [scrum_master.table].user_id = [user.table].Id WHERE [user.table].Id = @userId AND [scrum_master.table].project_id = @projectId";

            SqlCommand myCommand1 = new SqlCommand(query1, myConnection1);

            // passes variables through paramaters using Session values
            myCommand1.Parameters.AddWithValue("@userId", masterId);
            myCommand1.Parameters.AddWithValue("@projectId", project_id);

            // Decalres SqlReader to read from the database 
            SqlDataReader rdr1 = myCommand1.ExecuteReader();
            while (rdr1.Read())
            {
                // reads the value of column "Master" and assigns it to string
                string id_master = rdr1["Master"].ToString();

                // Convert id_master to int
                int master = Convert.ToInt32(id_master);

                // Checks if "Master" column value = 0 and is not assigned a scrum master
                if (master == 0)
                {
                    Response.Redirect("Home.aspx");
                }

                // If "Master" column value = 1 and is assigned a scrum master
                else if (master == 1)
                {
                    // If "Master" is 1 then user id is assigned to the session masterId
                    masterId = int.Parse(Session["useridsession"].ToString());
                    //shows remove button if user is master
                    Remove.Visible = true;
                    // Sets Back button visibility to true
                    Back.Visible = true;
                }



            }

            // Closes reader
            rdr1.Close();

            // Closes myConnection
            myConnection.Close();

            // Closes myConnection1
            myConnection1.Close();
        }
            
    }


    protected void Back_Click(object sender, EventArgs e)
    {

        // Redirects webapp to AssignSprintBacklog.aspx
        Response.Redirect("AssignSprintBacklog.aspx");

    }
    protected void sprintBacklog_SelectedIndexChanged(object sender, EventArgs e)
    { 
        // sets Sessions current_story to the selected user story selected
        Session["current_story"] = int.Parse(sprintBacklogL.SelectedValue);

        // Sets Session value to int variable "currentStory"
        int currentStory = (int)Session["current_story"];
    
    }
    protected void ViewTasks_Click(object sender, EventArgs e)
    { 
        // Redirects webapp to ViewTasks.aspx
       // for (int x = 0; x < sprintBacklogL.Items.Count; x++)
        //{
            // Determine if the item is selected.
          //  if (sprintBacklogL.GetSelected(x))
                Response.Redirect("ViewTasks.aspx");
        //}
    }
    protected void SprintButton_Click(object sender, EventArgs e)
    {
        // Redirects webapp to Sprint.aspx
        Response.Redirect("Sprint.aspx");
    }
    protected void Remove_Click(object sender, EventArgs e)
    {
        // sets up connection string to connect to database
        string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        // declares sql connection type
        SqlConnection myConnection = new SqlConnection(connectionString);

        // opens connection
        myConnection.Open();


        string query = "UPDATE [story.table] SET [story.table].assigned ='0' WHERE [story.table].Id = @storyid";


        SqlCommand myCommand = new SqlCommand(query, myConnection);

        int story = (int)Session["current_story"];
        // passes variables through paramaters using Session values
        myCommand.Parameters.AddWithValue("@storyid", story);

        myCommand.ExecuteNonQuery();

        Response.Redirect("SprintBacklog.aspx");
    
    }
}
    

    