using System;
using System.Web.UI.WebControls;
using System.Net; 
using System.Net.Mail;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Collections.Generic;


public partial class _Default : System.Web.UI.Page
{
    // Declares a private int
    private int user_Id;
    private List<string> emails = new List<string>();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // sets up connection string to connect to database
            string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

            // declares sql connection type
            SqlConnection myConnection = new SqlConnection(connectionString);

            // opens connection
            myConnection.Open();

            // Sends query to database to get emails that are assigned to id's
            string query = "SELECT Id, Email FROM [user.table] WHERE Dev=1 AND Available=1 ";

            SqlCommand myCommand = new SqlCommand(query, myConnection);

            // executes a sql reader
            SqlDataReader rdr = myCommand.ExecuteReader();


            while (rdr.Read())
            {
                // retrieves email list 
                user_Id = (rdr.GetInt32(0));
                
                bool alreadyThere = false;
                foreach (ListItem item in emailList.Items)
                {
                    if (item.Value == emailList.ToString())
                    {
                        alreadyThere = true;
                        break;
                    }
                }
                if (!alreadyThere)
                {
                    // Adds items to listbox 
                    emailList.Items.Add(new ListItem(rdr.GetString(1), user_Id.ToString()));

                }


            }

            // closes reader
            rdr.Close();
        }
    // setting up email send fuction 
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        sendemail(txtSender.Text, txtReceiever.Text, txtSubject.Text, txtBody.Text, false);
    }

    public Boolean sendemail(string strFrom, string line, string strSubject, string strBody, bool IsBodyHTML)
    {
        
        MailMessage mm = new MailMessage();
        mm.From = new MailAddress(strFrom);
        mm.Subject = strSubject;
        mm.Body = strBody;
        mm.IsBodyHtml = IsBodyHTML;
        
        

        foreach (ListItem item in contactList.Items)
        {
            string email1 = item.Value;
            emails.Add(email1);
            
        }

        emails.RemoveAt(0);

        foreach (string item in emails)
        {
            line = string.Join(";", emails.ToArray());

            line = line.TrimStart(';'); 

            txtReceiever.Text = line;

            string email2 = item;
            mm.To.Add(new MailAddress(email2));
           
        }

        

        //Checking for Attachment
        if (txtAttachment.PostedFile != null)
        {
            try
            {
                string strFileName =
                System.IO.Path.GetFileName(txtAttachment.PostedFile.FileName);
                Attachment attachFile =
                new Attachment(txtAttachment.PostedFile.InputStream, strFileName);
                mm.Attachments.Add(attachFile);
            }
            catch
            {

            }
        }
        SmtpClient smtp = new SmtpClient();
        try
        {
            smtp.Host = "smtp.gmail.com";
            smtp.EnableSsl = true; //Depending on server SSL Settings true/false
            NetworkCredential NetworkCred = new NetworkCredential();
            NetworkCred.UserName = "citisix15@gmail.com";
            NetworkCred.Password = "CITproject";
            smtp.UseDefaultCredentials = true;
            smtp.Credentials = NetworkCred;
            smtp.Port = 587;//Specify your port No;
            smtp.Send(mm);
            return true;

        }
        catch
        {
            mm.Dispose();
            smtp = null;
            return false;
        }

    }



    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("BurnDownChart.aspx");

    }


    protected void emailList_SelectedIndexChanged(object sender, EventArgs e)
    {

        // sets Sessions to the selected user 
        Session["current_user"] = int.Parse(emailList.SelectedValue);

        // Sets Session value to int variable "user"
        int currentUser = (int)Session["current_user"];
       

    }

    // ADDS from emaillist to the list of contacts get emails.
    protected void addToList_Click(object sender, EventArgs e)
    {
            user_Id = int.Parse(Session["current_user"].ToString());

         // sets up connection string to connect to database
            string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

            // declares sql connection type
            SqlConnection myConnection = new SqlConnection(connectionString);

            // opens connection
            myConnection.Open();

            // Sends query to database to get user data that are assigned to ids
            string query = "SELECT [user.table].* FROM [user.table] WHERE [user.table].Id = @userId";

            SqlCommand myCommand = new SqlCommand(query, myConnection);

           // passes variables through paramaters using Session values
            myCommand.Parameters.AddWithValue("@userId", user_Id);

            // executes a sql reader
            SqlDataReader rdr = myCommand.ExecuteReader();


            while (rdr.Read())
            {

                string myUser = rdr["Email"].ToString();
                
                contactList.Items.Add(new ListItem(myUser));
                
            }
      
    }
}
