﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ViewProjBacklog : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // makes sure the user is logged
        int user_id = 0;
        if (Session["useridsession"] == null)
        {

            Response.Redirect("Default.aspx");

        }

        else
        {
            user_id = int.Parse(Session["useridsession"].ToString());

        }
        int project_id = int.Parse(Session["current_project"].ToString()); //Takes the id of the current project

        string connectionString = WebConfigurationManager.ConnectionStrings["scrumconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);
        myConnection.Open();

        string query = "SELECT Id, description FROM [story.table] WHERE [story.table].project_id = @project";

        SqlCommand myCommand = new SqlCommand(query, myConnection);

        myCommand.Parameters.AddWithValue("@project", project_id);

        SqlDataReader rdr = myCommand.ExecuteReader();

        while (rdr.Read())
        {
            Stories.Items.Add(new ListItem(rdr.GetString(1), rdr.GetInt32(0).ToString()));
            
        }
        rdr.Close();

        
    }
}