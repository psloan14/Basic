﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

using System.Text;
using System.Configuration;

public partial class Results : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
            int userid = 0;
            if (Session["useridsession"] == null)
            {

                Response.Redirect("Default.aspx");

            }

            else
            {
                userid = int.Parse(Session["useridsession"].ToString());
            }
            
            string connectionString = WebConfigurationManager.ConnectionStrings["qsisconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();
        
        string query = "SELECT [module_Id], [moduleResult], [pass/Fail] FROM [Results] WHERE [Results].user_Id = @userid";


        SqlCommand myCommand = new SqlCommand(query, myConnection);
        myCommand.Parameters.AddWithValue("@userid", userid);

        SqlDataReader rdr = myCommand.ExecuteReader();



        while (rdr.Read())
        {
            TableCell cell1 = new TableCell();
            TableCell cell2 = new TableCell();
            TableCell cell3 = new TableCell();
            


            int module_Id = (rdr.GetInt32(0));
            string moduleResult = (rdr.GetString(1));
            string passFail = (rdr.GetString(2));

            cell1.Text = module_Id.ToString();
            cell2.Text = moduleResult.ToString();
            cell3.Text = passFail.ToString();
            


            TableRow row = new TableRow();

            row.Cells.Add(cell1);
            row.Cells.Add(cell2);
            row.Cells.Add(cell3);
            

            resultstable.Rows.Add(row);

            
        }
    


myConnection.Close();
            rdr.Close();            
    }
    }



