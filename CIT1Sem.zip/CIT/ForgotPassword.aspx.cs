﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;
using System.Drawing;
using System.Configuration;
using System.Data.SqlClient;

public partial class ForgotPassword : System.Web.UI.Page

    
{

    protected void SendEmail(object sender, EventArgs e)
    {

        // Sets up empty string waiting for input from database.
        // Sets variable for secret answer.
        string username = string.Empty;
        string password = string.Empty;
        string secret = secretAnswer.Text;

        // Connect to database.
        string constr = ConfigurationManager.ConnectionStrings["qsisconnection"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {

            // Query to select and compare variables such as Username, Password etc.
            using (SqlCommand cmd = new SqlCommand("SELECT usersTable.firstName, PasswordsTable.password,secretAnswer FROM usersTable INNER JOIN PasswordsTable ON usersTable.Id = PasswordsTable.user_Id WHERE usersTable.email = @Email AND secretAnswer = @secret"  ))
            {
                cmd.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());
                cmd.Parameters.AddWithValue("@secret", secretAnswer.Text.Trim());
                cmd.Connection = con;
                con.Open();
                using (SqlDataReader sdr = cmd.ExecuteReader())
                {
                    if (sdr.Read())
                    {
                        // Attachs name and password to previously set up emtpy string 
                        username = sdr["firstName"].ToString();
                        password = sdr["password"].ToString();
                    }
                }
                con.Close();
            }
        }
        if (!string.IsNullOrEmpty(password))

            // And pre set up automated email pulling the 2 strings mentions above into the message.
            // Also all needed credentials and protocols.
        {
            MailMessage mm = new MailMessage("citisix15@gmail.com ", txtEmail.Text.Trim());
            mm.Subject = "Password Recovery";
            mm.Body = string.Format("Hi {0},<br /><br />Your password is {1}.<br /><br />Thank You.", username, password);
            mm.IsBodyHtml = true;
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.EnableSsl = true;
            NetworkCredential NetworkCred = new NetworkCredential();
            NetworkCred.UserName = "citisix15@gmail.com ";
            NetworkCred.Password = "CITproject";
            smtp.UseDefaultCredentials = true;
            smtp.Credentials = NetworkCred;
            smtp.Port = 587;
            smtp.Send(mm);
            lblMessage.ForeColor = Color.Green;
            lblMessage.Text = "Password has been sent to your email address.";
        }
        else
        {
            lblMessage.ForeColor = Color.Red;
            lblMessage.Text = "This email address or secret answer does not match our records.";
        }
    }
}