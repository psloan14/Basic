﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Admin_StudentRecords : System.Web.UI.Page
{
    private static List<Tuple<int, string>> results = new List<Tuple<int, string>>();
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    //method executed when the search for Students is started(press the button)
    protected void SearchforStud_Click(object sender, EventArgs e)
    {
        //cleans the lists in each new search
        studentslist.Items.Clear();
        results.Clear();

        //gets the tags the user wrote
        string searchdata = SearchStud.Text;

        string connectionString = WebConfigurationManager.ConnectionStrings["qsisconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();
        //query to find students matching the criterion.
        string query = "SELECT studentRecord.student_Id, usersTable.email FROM studentRecord INNER JOIN usersTable ON usersTable.Id = studentRecord.student_Id WHERE student_Id = @searchdata";

        SqlCommand myCommand = new SqlCommand(query, myConnection);

        myCommand.Parameters.AddWithValue("@searchdata", searchdata);
        SqlDataReader rdr = myCommand.ExecuteReader();

        //stores the results in a list for later use.
        while (rdr.Read())
        {
            results.Add(new Tuple<int, string>(rdr.GetInt32(0), rdr.GetString(1)));
        }
        //displays the results in a list
        foreach (Tuple<int, string> item in results)
        {
            studentslist.Items.Add(new ListItem(item.Item2));
        }

    }

    protected void studentslist_SelectedIndexChanged(object sender, EventArgs e)
    {

        Session["useridsession"] = studentslist.SelectedItem.Text;

    }
    protected void view_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewStudentRecord.aspx");
    }

}