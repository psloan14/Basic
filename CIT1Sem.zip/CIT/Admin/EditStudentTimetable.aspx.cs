﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;


public partial class Admin_EditStudentTimetable : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void submit_Click(object sender, EventArgs e)
    {
        string connectionString = WebConfigurationManager.ConnectionStrings["qsisconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();

        string datep = Convert.ToString(datepicked.SelectedDate.DayOfWeek);
        
        DateTime time = Convert.ToDateTime(Time.SelectedValue);
        string ttime = Convert.ToString(time.TimeOfDay);
        

        string eventname = EventName.Text;

        string query = "UPDATE Timetable SET "+ datep + "= @event WHERE StudentId=@student AND Time=@time ";

        SqlCommand myCommand = new SqlCommand(query, myConnection);

       
        myCommand.Parameters.AddWithValue("@time", ttime);
        myCommand.Parameters.AddWithValue("@student", 1);
        myCommand.Parameters.AddWithValue("@event", eventname);

        myCommand.ExecuteNonQuery();
        myConnection.Close();

        Response.Redirect("Default.aspx");
    }
}