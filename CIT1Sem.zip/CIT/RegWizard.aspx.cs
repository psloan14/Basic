﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO; 
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class RegWizard : System.Web.UI.Page
{
    private static int row = 0;
    private static List<Tuple<int, string>> results1 = new List<Tuple<int, string>>();
    private static List<Tuple<int, string>> results = new List<Tuple<int, string>>();
    private static List<Tuple<int, string>> results2 = new List<Tuple<int, string>>();
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            

            if (Session["useridsession"] == null)
            {
                Response.Redirect("Default.aspx");
            }

            else
            {
                row = int.Parse(Session["useridsession"].ToString());
            }

            int year = (System.DateTime.Now.Year);
            for (int intCount = year; intCount >= 1980; intCount--)
            {
                DropDownList2.Items.Add(intCount.ToString());
            }

            viewchoice.NavigateUrl = "ModuleChoice.aspx?id=" + row.ToString();
           
            string connectionString = WebConfigurationManager.ConnectionStrings["qsisconnection"].ConnectionString;
            SqlConnection myConnection = new SqlConnection(connectionString);

            // myConnection.ConnectionString is now set to connectionString.
            myConnection.Open();


            string query = "SELECT studentAcademicRecord.*, Modules_Info.*, ModulesDescription.* FROM studentAcademicRecord FULL OUTER JOIN Modules_Info ON studentAcademicRecord.currentYear = Modules_Info.module_year INNER JOIN ModulesDescription ON ModulesDescription.description_Id = Modules_Info.moduleDescription_Id WHERE studentAcademicRecord.student_Id=@Id AND Modules_Info.compulsory_Module = 1";

            SqlCommand myCommand = new SqlCommand(query, myConnection);
            myCommand.Parameters.AddWithValue("@Id", row);

            SqlDataReader rdr = myCommand.ExecuteReader();


            //Getting the Module code from the database and putting it in the list

            while (rdr.Read())
            {

                results.Add(new Tuple<int, string>(rdr.GetInt32(5), rdr.GetString(21)));
                
            }
            Compmoduleslist.Items.Clear();
            foreach (Tuple<int, string> item in results)
            //foreach(string item in results)
            {

                Compmoduleslist.Items.Add(new ListItem(item.Item2));
                
            }


            rdr.Close();

            myCommand.ExecuteNonQuery();
            foreach (ListItem item in Compmoduleslist.Items)
            {
                int id_module = 0;
                foreach (Tuple<int, string> thing in results)
                {
                    if (thing.Item2 == item.Text)
                    {
                        id_module = thing.Item1;
                        break;
                    }
                }


                string query3 = "INSERT INTO StudentModules(student_id, module_id) VALUES (@user, @module)";

                SqlCommand myCommand2 = new SqlCommand(query3, myConnection);

                myCommand2.Parameters.AddWithValue("@user", row);
                myCommand2.Parameters.AddWithValue("@module", id_module);
                myCommand2.ExecuteNonQuery();



            }

            // query to select optional modules from the database 
            query = "SELECT studentAcademicRecord.*, Modules_Info.*, ModulesDescription.* FROM studentAcademicRecord FULL OUTER JOIN Modules_Info ON studentAcademicRecord.currentYear = Modules_Info.module_year INNER JOIN ModulesDescription ON ModulesDescription.description_Id = Modules_Info.moduleDescription_Id WHERE studentAcademicRecord.student_Id=@Id AND Modules_Info.compulsory_Module = 2";


            myCommand = new SqlCommand(query, myConnection);
            myCommand.Parameters.AddWithValue("@Id", row);

            rdr = myCommand.ExecuteReader();


            while (rdr.Read())
            {

                results1.Add(new Tuple<int, string>(rdr.GetInt32(5), rdr.GetString(11)));
                
            }
            Moduleslist.Items.Clear();
            foreach (Tuple<int, string> item in results1)
            {
                Moduleslist.Items.Add(new ListItem(item.Item2));
                
            }

            rdr.Close();

            myCommand.ExecuteNonQuery();

            query = ("SELECT student_Id, chargesDue FROM Finance WHERE student_Id=@Id");
            myCommand = new SqlCommand(query, myConnection);
            myCommand.Parameters.AddWithValue("@Id", row);

            rdr = myCommand.ExecuteReader();

            while (rdr.Read())
            {
                string moneyowed = rdr["chargesDue"].ToString();
                moneyowedlabel.Text = "You owe £" + moneyowed + " in tuition fees.";

            }
            rdr.Close();

            myCommand.ExecuteNonQuery();

            query = ("SELECT * FROM FinanceType");
            myCommand = new SqlCommand(query, myConnection);
           

            rdr = myCommand.ExecuteReader();


            while (rdr.Read())
            {

                results2.Add(new Tuple<int, string>(rdr.GetInt32(0), rdr.GetString(1)));

            }
            
            financetypelist.Items.Clear();
            foreach (Tuple<int, string> item in results2)
            {
                financetypelist.Items.Add(new ListItem(item.Item2));
            }
            rdr.Close();

            myCommand.ExecuteNonQuery();
            
        }
    }
    protected void RegistrationWizard_FinishButtonClick(object sender, WizardNavigationEventArgs e)
    {
        if (Session["useridsession"] == null)
        {

            Response.Redirect("Default.aspx");

        }

        else
        {
            row = int.Parse(Session["useridsession"].ToString());
        }
            
        string connectionString = WebConfigurationManager.ConnectionStrings["qsisconnection"].ConnectionString;
        SqlConnection myConnection = new SqlConnection(connectionString);

        // myConnection.ConnectionString is now set to connectionString.
        myConnection.Open();


        string emergencyContactNoData = EmergencyContact.Text;
        string doctorsNameData = Doctor.Text;
        string doctorPhoneNoData = DoctorNo.Text;
        string Mobileno = Mobile.Text;
        

        string query = "UPDATE studentRecord SET DOB='1991/04/18', emergencyContact=@nEmergencyContactNo, doctor=@nDoctor, doctorPhone=@nDoctorsPhoneNo, mobileNo=@nMobNo WHERE student_Id=@Id";

        SqlCommand myCommand = new SqlCommand(query, myConnection);

        string birth = (DropDownList1.SelectedItem + "/" + pickmonth.SelectedValue + "/" + DropDownList2.SelectedItem);

        DateTime birthdate = Convert.ToDateTime(birth);
        

        myCommand.Parameters.AddWithValue("@nDOB", birthdate);
        myCommand.Parameters.AddWithValue("@nEmergencyContactNo", emergencyContactNoData);
        myCommand.Parameters.AddWithValue("@nDoctor", doctorsNameData);
        myCommand.Parameters.AddWithValue("@nDoctorsPhoneNo", doctorPhoneNoData);
        myCommand.Parameters.AddWithValue("@nMobNo", Mobileno);
        myCommand.Parameters.AddWithValue("@Id", row);

        myCommand.ExecuteNonQuery();

        foreach (ListItem item in financetypelist.Items)
        {

            if (item.Selected)
            {
                int id_finance = 0;
                foreach (Tuple<int, string> thing in results2)
                {
                    if (thing.Item2 == item.Text)
                    {
                        id_finance = thing.Item1;
                        break;
                    }
                }


                string query2 = "UPDATE Finance SET financeType_Id=@finance WHERE student_Id=@user";

                SqlCommand myCommand1 = new SqlCommand(query2, myConnection);

                myCommand1.Parameters.AddWithValue("@user", row);
                myCommand1.Parameters.AddWithValue("@finance", id_finance);
                myCommand1.ExecuteNonQuery();


            }
        }

        query = ("UPDATE Finance SET bankSortCode=@sort, ACNumber=@account WHERE student_Id=@user");
        myCommand = new SqlCommand(query, myConnection);

        myCommand.Parameters.AddWithValue("@user", row);
        myCommand.Parameters.AddWithValue("@account", accountnumberinput.Text);
        myCommand.Parameters.AddWithValue("@sort", sortcodeinput.Text);
        myCommand.ExecuteNonQuery();
        
    }
    protected void submitmodules_Click(object sender, EventArgs e)
    {

        string connectionString = WebConfigurationManager.ConnectionStrings["qsisconnection"].ConnectionString;
        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();
        
        foreach (ListItem item in Moduleslist.Items)
        {
            int x = 0;
            if (item.Selected)
            {
                x = x++;
                int id_module1 = 0;
                foreach (Tuple<int, string> thing in results1)
                {
                    if (thing.Item2 == item.Text)
                    {
                        id_module1 = thing.Item1;
                        break;
                    }
                }

                if (x > 2) {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Select two Modules')", true);
                }
                string query2 = "INSERT INTO StudentModules(student_id, module_id) VALUES (@user, @module)";

                SqlCommand myCommand1 = new SqlCommand(query2, myConnection);

                myCommand1.Parameters.AddWithValue("@user", row);
                myCommand1.Parameters.AddWithValue("@module", id_module1);
                myCommand1.ExecuteNonQuery();

                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Modules Updated')", true);
            }
        }
    }

    protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
        /*
        Session["current_module"] = int.Parse(viewmodulelist.SelectedValue);
        Response.Redirect("ModuleDescription.aspx");
         */
    }

}