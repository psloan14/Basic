﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Drawing;


public partial class Settings : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void ChangePassword1_ChangedPassword(object sender, EventArgs e)
    {


    }

    protected void Change_Click(object sender, EventArgs e)
    {
        // Setting up Change Password.
        if (CurrentPassword1 != NewPassword1)
        {
            int rowsAffected = 0;
            String query = "UPDATE [PasswordsTable] SET [password] = @NewPassword WHERE [user_Id] = @Username AND [password] = @CurrentPassword";
            string connectionString = WebConfigurationManager.ConnectionStrings["qsisconnection"].ConnectionString;
            // Query to compare set and compare old password and new password .
            SqlConnection myConnection = new SqlConnection(connectionString);

            myConnection.Open();
            {
                using (SqlCommand cmd = new SqlCommand(query))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        SqlCommand myCommand = new SqlCommand(query, myConnection);
                        myCommand.Parameters.AddWithValue("@Username", Username1.Text);
                        myCommand.Parameters.AddWithValue("@CurrentPassword", CurrentPassword1.Text);
                        myCommand.Parameters.AddWithValue("@NewPassword", NewPassword1.Text);
                        myCommand.ExecuteNonQuery();

                        myConnection.Close();
                    }
                    // Various labels, results vary based on correct input or not.( these are still kinda buggy )
                    if (rowsAffected > 0)
                    {
                        lblMessage.ForeColor = Color.Green;
                        lblMessage.Text = "Password has been changed.";
                    }
                    else
                    {
                        lblMessage.ForeColor = Color.Red;
                        lblMessage.Text = "Password does not match records.";
                    }
                }
            }
        }

        else
        {
            lblMessage.ForeColor = Color.Red;
            lblMessage.Text = "passwords don't match";

        }
        }
    



    protected void ChangeAnswer_Click(object sender, EventArgs e)
    {
        // Setting up change Secret Answer.
        if (secretA != secretNew2)
        {
            int rowsAffected = 0;
            String query = "UPDATE [PasswordsTable] SET [secretAnswer] = @secretNew WHERE [user_Id] = @Username AND [secretAnswer] = @secretA";
            string connectionString = WebConfigurationManager.ConnectionStrings["qsisconnection"].ConnectionString;
            // Comparing and upated old and new secret answers.
            SqlConnection myConnection = new SqlConnection(connectionString);

            myConnection.Open();
            {
                using (SqlCommand cmd = new SqlCommand(query))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        SqlCommand myCommand = new SqlCommand(query, myConnection);
                        myCommand.Parameters.AddWithValue("@Username", username2.Text);
                        myCommand.Parameters.AddWithValue("@secretA", secretA.Text);
                        myCommand.Parameters.AddWithValue("@secretNew", secretNew2.Text);
                        myCommand.ExecuteNonQuery();

                        myConnection.Close();
                    }
                    // Various labels, results vary based on correct input or not.( these are still kinda buggy )
                }
                if (rowsAffected > 0)
                {
                    lblMessage1.ForeColor = Color.Green;
                    lblMessage1.Text = "Secret anwser does not match records.";
                }
               else
                {
                    lblMessage1.ForeColor = Color.Green;
                    lblMessage1.Text = "Anwser has been changed.";
                }
            }
        }
        else
        {
            lblMessage1.ForeColor = Color.Red;
            lblMessage1.Text = "Answers don't match";

        }
    }

}