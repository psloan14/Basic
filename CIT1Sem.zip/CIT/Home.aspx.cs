﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;


public partial class Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int row = 0;
        if (Session["useridsession"] == null)
        {

            Response.Redirect("Default.aspx");

        }

        else
        {
            row = int.Parse(Session["useridsession"].ToString());
        }

        string connectionString = WebConfigurationManager.ConnectionStrings["qsisconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();

        string query = "SELECT usersTable.*, studentAcademicRecord.*, School.*, Pathways.*, StudentModules.*, Modules_Info.*, ModulesDescription.* FROM usersTable INNER JOIN studentAcademicRecord ON usersTable.Id = studentAcademicRecord.student_Id INNER JOIN School ON studentAcademicRecord.school_Id = School.school_Id INNER JOIN Pathways ON studentAcademicRecord.pathway_Id = Pathways.pathway_Id INNER JOIN StudentModules ON usersTable.Id = StudentModules.student_Id INNER JOIN Modules_Info ON StudentModules.module_Id = Modules_Info.module_Id INNER JOIN ModulesDescription ON Modules_Info.moduleDescription_Id = ModulesDescription.description_Id WHERE usersTable.Id=@Id";

      
        SqlCommand myCommand = new SqlCommand(query, myConnection);

            myCommand.Parameters.AddWithValue("@Id", row);

            SqlDataReader rdr = myCommand.ExecuteReader();

            while (rdr.Read())
            {
                string myname = rdr["Id"].ToString();
                string fname = rdr["firstName"].ToString();
                string sname = rdr["surname"].ToString();
                string email = rdr["email"].ToString();
                UserName.Text = fname + " " + sname + " " + myname;
                Emaillabel.Text = email;

                string school = rdr["schoolName"].ToString();
                string pathway = rdr["name"].ToString();
                Schoollabel.Text = school;
                Pathwaylabel.Text = pathway;

                string module = rdr["module_code"].ToString();
                string modulename = rdr["module_name"].ToString();
                Moduleslabel.Text = module + ": " + modulename;

                
            }
            rdr.Close();    

            query = "SELECT competedregwiz FROM studentRecord WHERE student_Id=@Id";

            myCommand.Parameters.AddWithValue("@Id1", row);

            rdr = myCommand.ExecuteReader();
            int iscompleted = 0;
            while (rdr.Read())
            {
                iscompleted = rdr.GetInt32(0);
            }

            if (iscompleted == 0)
            {
                Panel1.Visible = true;
            }

    }

}