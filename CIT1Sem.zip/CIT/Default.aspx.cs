﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }

    protected void loginbutton_Click(object sender, EventArgs e)
    {
        
        string udata = username.Text;
        string pdata = password.Text;

        string connectionString = WebConfigurationManager.ConnectionStrings["qsisconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();
        
        string query = "SELECT PasswordsTable.*,usersTable.* FROM PasswordsTable INNER JOIN usersTable ON PasswordsTable.user_Id = usersTable.Id WHERE PasswordsTable.user_Id=@user AND PasswordsTable.password=@password";

        SqlCommand myCommand = new SqlCommand(query, myConnection);

        myCommand.Parameters.AddWithValue("@user", udata);
        myCommand.Parameters.AddWithValue("@password", pdata);

        
        //create a sqldatareader object that asks for data from a table
        SqlDataReader rdr = myCommand.ExecuteReader();

        if (rdr.HasRows)
        {
            while (rdr.Read())
            {

                string roleID = rdr["usertype_id"].ToString();
                Session["usertype_id"] = roleID;
                Session["useridsession"] = rdr["Id"].ToString();
                

                if (roleID == "1")
                {
                    Response.Redirect("Home.aspx");
                }
                if (roleID == "2")
                {
                    Response.Redirect("lecturer/Default.aspx");
                }
                if (roleID == "3")
                {
                    Response.Redirect("Admin/Default.aspx");
                }
                if (roleID == "4")
                {
                    Response.Redirect("AcademicProgramManager/Default.aspx");
                }
                if (roleID == "5")
                {
                    Response.Redirect("SeniorM/Default.aspx");
                }


                }
            }
        
       // else
       // {
            //feedback.Text = "login failed";
       // }


        //{
            //feedback.Text = "Unsuccessful login";
        //}

        username.Text = "";
        password.Text = "";

        myConnection.Close();
    }

    protected void forgotpasswordbutton_Click(object sender, EventArgs e)
    {
          Response.Redirect("ForgotPassword.aspx");
    }
}
  
