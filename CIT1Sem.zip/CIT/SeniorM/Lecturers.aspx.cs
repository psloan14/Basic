﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
public partial class SeniorM_Lecturers : System.Web.UI.Page
{
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            int lecturerid = 0;
            if (Request.QueryString["lecturerid"] != null)
            {
                
                lecturerid = int.Parse(Request.QueryString["lecturerid"]);
            }
            else
            {
                
                Response.Redirect("/Default.aspx");
            }

           


            string connectionString = WebConfigurationManager.ConnectionStrings["qsisconnection"].ConnectionString;

            SqlConnection myConnection = new SqlConnection(connectionString);

            myConnection.Open();

            string query = "SELECT usersTable.*, School.*, staffRecord.* FROM School INNER JOIN staffRecord ON School.school_Id = staffRecord.School_Id INNER JOIN usersTable ON staffRecord.staff_Id = usersTable.ID WHERE usersTable.ID = @Id";


            SqlCommand myCommand = new SqlCommand(query, myConnection);
            int StaffId = int.Parse(Request.QueryString["lecturerid"]);
            myCommand.Parameters.AddWithValue("@Id", StaffId);

            SqlDataReader rdr = myCommand.ExecuteReader();

            while (rdr.Read())
            {

                string fname = rdr["firstName"].ToString();
                string sname = rdr["surname"].ToString();
                string email = rdr["email"].ToString();
                string schoolId = rdr["schoolName"].ToString();
                string OfficeNumber = rdr["workNo"].ToString();
                DateTime StartingDate = (DateTime)rdr["employmentStart"];
                string startdate = Convert.ToString(StartingDate.Date.Day + "/" + StartingDate.Month + "/" + StartingDate.Year);
                

                StaffID.Text = StaffId.ToString();
                LName.Text = fname + " " + sname;
                Email.Text = email;
                School.Text = schoolId;
                OfficeNo.Text = OfficeNumber;
                StartDate.Text = startdate;



            }

            

        }
    }

    
}


    



