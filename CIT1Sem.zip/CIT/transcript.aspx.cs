﻿using System;
using System.Web;
using System.Data.SqlClient;
using System.Web.Configuration;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;
using System.Web.UI;
using iTextSharp.text.html.simpleparser;

public partial class transcript : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int row = 0;
        if (Session["useridsession"] == null)
        {

            Response.Redirect("Default.aspx");

        }

        else
        {
            row = int.Parse(Session["useridsession"].ToString());
        }

        string connectionString = WebConfigurationManager.ConnectionStrings["qsisconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();

        string query = "SELECT usersTable.*, studentAcademicRecord.*, School.*, Pathways.*, StudentModules.*, Modules_Info.*, ModulesDescription.* FROM usersTable INNER JOIN studentAcademicRecord ON usersTable.Id = studentAcademicRecord.student_Id INNER JOIN School ON studentAcademicRecord.school_Id = School.school_Id INNER JOIN Pathways ON studentAcademicRecord.pathway_Id = Pathways.pathway_Id INNER JOIN StudentModules ON usersTable.Id = StudentModules.student_Id INNER JOIN Modules_Info ON StudentModules.module_Id = Modules_Info.module_Id INNER JOIN ModulesDescription ON Modules_Info.moduleDescription_Id = ModulesDescription.description_Id WHERE usersTable.Id=@Id";


        SqlCommand myCommand = new SqlCommand(query, myConnection);

        myCommand.Parameters.AddWithValue("@Id", row);

        SqlDataReader rdr = myCommand.ExecuteReader();

        while (rdr.Read())
        {
            string id = rdr["Id"].ToString();
            string fname = rdr["firstName"].ToString();
            string sname = rdr["surname"].ToString();
            string email = rdr["email"].ToString();
            UserName.Text = fname + " " + sname;
            Id.Text = id;
            Emaillabel.Text = email;

            string school = rdr["schoolName"].ToString();
            string pathway = rdr["name"].ToString();
            Schoollabel.Text = school;
            Pathwaylabel.Text = pathway;


        }
    }

    // Sets up a save as PDF Document.
        protected void btnShow_OnClick(object sender, EventArgs e)
    {
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "attachment;filename=Student Transcript.pdf");
        Response.Cache.SetCacheability(HttpCacheability.NoCache);

        StringWriter stringWriter = new StringWriter();
        HtmlTextWriter htmlTextWriter = new HtmlTextWriter(stringWriter);
        box3.RenderControl(htmlTextWriter);

        StringReader stringReader = new StringReader(stringWriter.ToString());
        Document Doc = new Document(PageSize.A4, 10f, 10f, 100f, 0f);
        HTMLWorker htmlparser = new HTMLWorker(Doc);
        PdfWriter.GetInstance(Doc, Response.OutputStream);

        Doc.Open();
        htmlparser.Parse(stringReader);
        Doc.Close();
        Response.Write(Doc);
        Response.End();
    }
    public override void VerifyRenderingInServerForm(Control control)
    {

    }
}     
    


