﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class AcademicProgramManager_VerifyModuleChanges : System.Web.UI.Page
{

    private string updatePrerequisites;
    private string updateLearningOutcomes;
    private string updateSkills;
    private string updateModuleContent;
    private string updateModuleName;
    private string updateLecturerName;
    private string updateLecturerEmail;
    
    protected void Page_Load(object sender, EventArgs e)
    {
         if (!IsPostBack)
        {
            int moduleid = 0;
            if (Request.QueryString["moduleId"] != null)
            {
                //if it does exist in URL then do this...
                moduleid = int.Parse(Request.QueryString["moduleId"]);
            }
            else
            {
                //if there is no querystring in URL then redirect page...
                Response.Redirect("Default.aspx");
            }

               // checks if user is a an Academic Program Manager

        int userType = 0;
        if (Session["usertype_id"] != null)
        {
            userType = int.Parse(Session["usertype_id"].ToString());


        }


        if (userType != 4)
        {
            Response.Redirect("~/Home.aspx");
        }
    

                // set-up object to use the web.config file
                string connectionString = WebConfigurationManager.ConnectionStrings
                ["qsisconnection"].ConnectionString;

                //set-up connection object called 'myConnection'
                SqlConnection myConnection = new SqlConnection(connectionString);

                //open database communication
                myConnection.Open();


                //create the SQL statement
                string query = "SELECT module_changes.*, Modules_Info.*, usersTable.* FROM module_changes INNER JOIN Modules_Info ON module_changes.description_Id = Modules_Info.moduleDescription_Id INNER JOIN usersTable ON module_changes.lecturerId = usersTable.Id WHERE module_changes.Id = @moduleId";

                //set-up SQL command and use the SQL and myConnection object
                SqlCommand myCommand = new SqlCommand(query, myConnection);
                //create a parameterised object
                myCommand.Parameters.AddWithValue("moduleId", moduleid);

                //create a sqldatareader object that asks for data from a table
                SqlDataReader rdr = myCommand.ExecuteReader();


                //when in read mode ask for data
                while (rdr.Read())
                {
                    //put field data from 'firstName' into variable
                    string mylecturerName= rdr["firstName"].ToString();
                    //put variable value into label 'lecturerName'
                    lecturerName.Text = mylecturerName;
                    updateLecturerName = mylecturerName;

                    //put field data from 'email' into variable
                    string myEmail = rdr["email"].ToString();
                    //put variable value into textbox lecturerEmail.Text
                    lecturerEmail.Text = myEmail;
                    updateLecturerEmail = myEmail;

                    //put field data from 'prerequisites' into variable
                    string myModulePrerequisites = rdr["prerequisites"].ToString();
                    //put variable value into textbox modulePreprerequisites.Text
                    modulePrerequisites.Text = myModulePrerequisites;
                    updatePrerequisites = myModulePrerequisites;

                    //put field data from 'learning_outcomes' into variable
                    string moduleLearningOutcomes = rdr["learning_outcomes"].ToString();
                    //put variable value into textbox learningOutcomes.Text
                    learningOutcomes.Text = moduleLearningOutcomes;
                    updateLearningOutcomes = moduleLearningOutcomes;

                    //put field data from 'skills' into variable
                    string myModuleSkills = rdr["skills"].ToString();
                    //put variable value into textbox moduleSkills.Text
                    moduleSkills.Text = myModuleSkills;
                    updateSkills = myModuleSkills;

                    //put field data from 'module_content' into variable
                    string myModuleContent = rdr["module_content"].ToString();
                    //put variable value into textbox learningOutcomes.Text
                    moduleContent.Text = myModuleContent;
                    updateModuleContent = myModuleContent;

                    //put field data from 'module_name' into variable
                    string myModuleCode = rdr["module_code"].ToString();
                    //put variable value into textbox moduleName.Text
                    moduleCode.Text = myModuleCode;
                    updateModuleName = myModuleCode;

                    //put field data from 'module_name' into variable
                    string myModuleName = rdr["module_name"].ToString();
                    //put variable value into textbox moduleName.Text
                    moduleName.Text = myModuleName;
                    updateModuleName = myModuleName;
                    

                }
            }
           
    }




    protected void approveModuleChanges_Click(object sender, EventArgs e)
    {

         // set-up object to use the web.config file
        string connectionString = WebConfigurationManager.ConnectionStrings
        ["qsisconnection"].ConnectionString;

        // set-up connection object called 'myConnection'
        SqlConnection myConnection = new SqlConnection(connectionString);

        // open database communication
        myConnection.Open();

        string updateModulePrerequisites = modulePrerequisites.Text;
        string updateLearningOutcomes = learningOutcomes.Text;
        string updateSkills = moduleSkills.Text;
        string updateModuleContent = moduleContent.Text;
        string updateModuleName = moduleName.Text;
        
        

        int moduleid = int.Parse(Request.QueryString["moduleId"]);

        int userId = int.Parse(Session["useridsession"].ToString());

        string query = "UPDATE ModulesDescription SET prerequisites = @prerequisites, learning_outcomes = @learning_outcomes, skills = @skills, module_content = @module_content, module_name = @module_name WHERE description_Id = @moduleId";

        SqlCommand myCommand = new SqlCommand(query, myConnection);
        //create a parameterised object
        myCommand.Parameters.AddWithValue("@prerequisites", updateModulePrerequisites);
        myCommand.Parameters.AddWithValue("@learning_outcomes", updateLearningOutcomes);
        myCommand.Parameters.AddWithValue("@skills", updateSkills);
        myCommand.Parameters.AddWithValue("@module_content", updateModuleContent);
        myCommand.Parameters.AddWithValue("@module_name", updateModuleName);
        myCommand.Parameters.AddWithValue("@moduleId", moduleid);

      

        myCommand.ExecuteNonQuery();


        myConnection.Close();


        // set-up object to use the web.config file
        string connectionString1 = WebConfigurationManager.ConnectionStrings
        ["qsisconnection"].ConnectionString;

        // set-up connection object called 'myConnection'
        SqlConnection myConnection1 = new SqlConnection(connectionString1);

        // open database communication
        myConnection1.Open();

        
        string query1 = "DELETE FROM module_changes WHERE Id = @moduleId";
        
        SqlCommand myCommand1 = new SqlCommand(query1, myConnection1);
        //create a parameterised object
        
        myCommand1.Parameters.AddWithValue("@moduleId", moduleid);
     

        myCommand1.ExecuteNonQuery();


        myConnection1.Close();

        ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "alert('You have approved changes for this module.');", true);
        return;

    }
    protected void backButton_Click(object sender, EventArgs e)
    {
        Response.Redirect("ApproveModuleChanges.aspx");
    }
}

  
