﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class AcademicProgramManager_EditModuleDetails : System.Web.UI.Page
{
    private string updatePrerequisites;
    private string updateLearningOutcomes;
    private string updateSkills;
    private string updateModuleContent;
    private string updateModuleName;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            
            int moduleid = 0;
            if (Request.QueryString["moduleId"] != null)
            {
                //if it does exist in URL then do this...
                moduleid = int.Parse(Request.QueryString["moduleId"]);
            }
            else
            {
                //if there is no querystring in URL then redirect page...
                Response.Redirect("Default.aspx");
            }

               // checks if user is a an Academic Program Manager

        int userType = 0;
        if (Session["usertype_id"] != null)
        {
            userType = int.Parse(Session["usertype_id"].ToString());


        }


        if (userType != 4)
        {
            Response.Redirect("~/Home.aspx");
        }
    

                // set-up object to use the web.config file
                string connectionString = WebConfigurationManager.ConnectionStrings
                ["qsisconnection"].ConnectionString;

                //set-up connection object called 'myConnection'
                SqlConnection myConnection = new SqlConnection(connectionString);

                //open database communication
                myConnection.Open();

                //create the SQL statement
                string query = "SELECT ModulesDescription.*, Modules_Info.*, lecturermodules.* FROM ModulesDescription INNER JOIN Modules_Info ON ModulesDescription.description_Id = Modules_Info.moduleDescription_Id INNER JOIN lecturermodules ON lecturermodules.moduleid = Modules_Info.module_Id WHERE Modules_Info.module_Id = @moduleId";

                //set-up SQL command and use the SQL and myConnection object
                SqlCommand myCommand = new SqlCommand(query, myConnection);
                //create a parameterised object
                myCommand.Parameters.AddWithValue("moduleId", moduleid);

                //create a sqldatareader object that asks for data from a table
                SqlDataReader rdr = myCommand.ExecuteReader();


                //when in read mode ask for data
                while (rdr.Read())
                {
                    //put field data from 'prerequisites' into variable
                    string myModulePrerequisites = rdr["prerequisites"].ToString();
                    //put variable value into textbox modulePreprerequisites.Text
                    modulePrerequisites.Text = myModulePrerequisites;
                    updatePrerequisites = myModulePrerequisites;

                    //put field data from 'learning_outcomes' into variable
                    string moduleLearningOutcomes = rdr["learning_outcomes"].ToString();
                    //put variable value into textbox learningOutcomes.Text
                    learningOutcomes.Text = moduleLearningOutcomes;
                    updateLearningOutcomes = moduleLearningOutcomes;

                    //put field data from 'skills' into variable
                    string myModuleSkills = rdr["skills"].ToString();
                    //put variable value into textbox moduleSkills.Text
                    moduleSkills.Text = myModuleSkills;
                    updateSkills = myModuleSkills;

                    //put field data from 'module_content' into variable
                    string myModuleContent = rdr["module_content"].ToString();
                    //put variable value into textbox learningOutcomes.Text
                    moduleContent.Text = myModuleContent;
                    updateModuleContent = myModuleContent;

                    string moduleName = rdr["module_name"].ToString();
                    updateModuleName = moduleName;

                }
            }

       
          
        }
    
    protected void updateModuleButton_Click(object sender, EventArgs e)
    {


        // set-up object to use the web.config file
        string connectionString = WebConfigurationManager.ConnectionStrings
        ["qsisconnection"].ConnectionString;

        // set-up connection object called 'myConnection'
        SqlConnection myConnection = new SqlConnection(connectionString);

        // open database communication
        myConnection.Open();

        string updateModulePrerequisites = modulePrerequisites.Text;
        string updateLearningOutcomes = learningOutcomes.Text;
        string updateSkills = moduleSkills.Text;
        string updateModuleContent = moduleContent.Text;

        int moduleid = int.Parse(Request.QueryString["moduleId"]);


        string query = "UPDATE [ModulesDescription] SET [prerequisites]=@prerequisites, [learning_outcomes]=@learning_outcomes, [skills]=@skills, [module_content]=@module_content WHERE [description_Id]=@id";

        SqlCommand myCommand = new SqlCommand(query, myConnection);
        //create a parameterised object
        myCommand.Parameters.AddWithValue("@prerequisites", updateModulePrerequisites);
        myCommand.Parameters.AddWithValue("@id", moduleid);
        myCommand.Parameters.AddWithValue("@learning_outcomes", updateLearningOutcomes);
        myCommand.Parameters.AddWithValue("@skills", updateSkills);
        myCommand.Parameters.AddWithValue("@module_content", updateModuleContent);

        myCommand.ExecuteNonQuery();


        myConnection.Close();


        ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "alert('You have updated details for this module');", true);
        return;

    }
   
}