﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AcademicProgramManager_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
            // checks if user is a an Academic Program Manager

        int userType = 0;
        if (Session["usertype_id"] != null)
        {
            userType = int.Parse(Session["usertype_id"].ToString());


        }


        if (userType != 4)
        {
            Response.Redirect("~/Home.aspx");
        }
    }

    }
