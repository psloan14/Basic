﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;


public partial class lecturer_addstudentresults : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       

        
    }

    
        
    protected void addresults_Click(object sender, EventArgs e)
    {
       

            
      
            
        string connectionString = WebConfigurationManager.ConnectionStrings["qsisconnection"].ConnectionString;

        SqlConnection myConnection = new SqlConnection(connectionString);

        myConnection.Open();

        string addstudentid = studentid.Text;
        string addmoduleid = moduleid.Text;
        string addmoduleresult = moduleresult.Text;
        string addpassorfail = passorfail.Text;
        int convertedmoduleid = Convert.ToInt32(addmoduleid);
        int convertedstudentid = Convert.ToInt32(addstudentid);
        

       
        
        
        string query = "INSERT INTO Results (user_Id, module_Id, moduleResult, [pass/Fail]) VALUES (@studentid, @insertmoduleid, @insertmoduleresult, @insertmodulepassorfail)";
        
        SqlCommand myCommand = new SqlCommand(query, myConnection);

       
        myCommand.Parameters.AddWithValue("@studentid", addstudentid);
        myCommand.Parameters.AddWithValue("@insertmoduleid", addmoduleid);
        myCommand.Parameters.AddWithValue("@insertmoduleresult", addmoduleresult);
        myCommand.Parameters.AddWithValue("@insertmodulepassorfail", addpassorfail);
        

        



        myCommand.ExecuteNonQuery();
        myConnection.Close();

        updatesuccessful.Text = "Results added successfully";

        studentid.Text = "";
        moduleid.Text = "";
        moduleresult.Text = "";
        passorfail.Text = "";

    }
}