﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

using System.Text;
using System.Configuration;

public partial class lecturer_viewmodules : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        int userType = 0;
        if (Session["usertype_id"] != null)
        {
            userType = int.Parse(Session["usertype_id"].ToString());


        }


        if (userType != 2)
        {
            Response.Redirect("~/Home.aspx");
        }

        int userId = 0;
        if (Session["useridsession"] != null)
        {
            userId = int.Parse(Session["useridsession"].ToString());
        }
        else
        {
            Response.Redirect("Default.aspx");
        }
       
    }
}

